#include<stdio.h>

int main()
{
	char c[20];
	gets(c);
	printf("%s",c);
	return 0;
}
