--
-- openGauss database dump
--

SET statement_timeout = 0;
SET xmloption = content;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET session_replication_role = replica;
SET client_min_messages = warning;

SET search_path = public;

--
-- Name: add_production_task_(character varying, character varying, integer, timestamp without time zone, timestamp without time zone, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: u
--

CREATE PROCEDURE add_production_task_(
    p_task_id VARCHAR(20),
    p_product_id VARCHAR(20),
    p_plan_quantity INT,
    p_plan_start TIMESTAMP,
    p_plan_end TIMESTAMP,
    p_order_id VARCHAR(20),
    p_status VARCHAR(10) DEFAULT '未开始',
    o_result OUT VARCHAR(200)
)  NOT SHIPPABLE
 AS  DECLARE BEGIN
    -- 参数合法性校验
    IF NOT EXISTS (SELECT 1 FROM product_ WHERE product_id = p_product_id) THEN
        o_result := '创建失败：产品ID【'||p_product_id||'】不存在！';
        RETURN;
    END IF;
    IF p_plan_quantity <= 0 THEN
        o_result := '创建失败：计划产量必须为正数！';
        RETURN;
    END IF;
    IF p_plan_end < p_plan_start THEN
        o_result := '创建失败：计划结束时间不能早于计划开始时间！';
        RETURN;
    END IF;
    IF EXISTS (SELECT 1 FROM task_ WHERE task_id = p_task_id) THEN
        o_result := '创建失败：任务ID【'||p_task_id||'】已存在！';
        RETURN;
    END IF;
    
    -- 插入生产任务数据
    INSERT INTO task_ (task_id, product_id, plan_quantity, plan_start, plan_end, order_id, status)
    VALUES (p_task_id, p_product_id, p_plan_quantity, p_plan_start, p_plan_end, p_order_id, p_status);
    
    o_result := '生产任务创建成功，任务ID：' || p_task_id;
EXCEPTION
    WHEN OTHERS THEN
        o_result := '创建失败：' || SQLERRM;
END;
/


ALTER PROCEDURE public.add_production_task_(p_task_id character varying, p_product_id character varying, p_plan_quantity integer, p_plan_start timestamp without time zone, p_plan_end timestamp without time zone, p_order_id character varying, p_status character varying, OUT o_result character varying) OWNER TO u;

--
-- Name: auto_insert_task_exec_safe(integer); Type: FUNCTION; Schema: public; Owner: u
--

CREATE FUNCTION auto_insert_task_exec_safe(insert_count integer) RETURNS void
    LANGUAGE plpgsql NOT SHIPPABLE
 AS $$
DECLARE
    v_task_id VARCHAR(20);        -- 随机选中的任务ID
    v_plan_qty INT;               -- 任务的计划产量
    v_current_sum INT;            -- 任务当前已完成的累计产量
    v_random_num INT;             -- 本次要随机生成的数量(5~30)
    v_real_insert_num INT;        -- 最终实际插入的数量（核心：超量则改为刚好达标）
    v_operator VARCHAR(20);       -- 随机员工ID
    v_exec_time TIMESTAMP;        -- 随机执行时间
BEGIN
    -- 循环生成指定条数的记录
    FOR i IN 1..insert_count LOOP
        -- ========== 1. 随机选一个任务 + 查询【最新】的累计完成量和计划量 ==========
        SELECT 
            t.task_id,
            t.plan_quantity,
            COALESCE(SUM(e.completed_quantity), 0)
        INTO v_task_id, v_plan_qty, v_current_sum
        FROM task_ t
        LEFT JOIN task_exec_ e ON t.task_id = e.task_id
        GROUP BY t.task_id, t.plan_quantity
        HAVING t.plan_quantity - COALESCE(SUM(e.completed_quantity), 0) > 0
        ORDER BY random() LIMIT 1;
        
        -- 如果所有任务都已完成，直接退出循环
        IF v_task_id IS NULL THEN EXIT; END IF;
        
        -- ========== 2. 核心逻辑【你要的精准校验+自动修正】 ==========
        v_random_num = floor(random()*51 +1)::INT;  -- 固定生成 5~30 的随机数（合理生产批量）
        -- 插入前判断：随机数+累计数 > 计划数 → 超量！则改为【刚好凑齐计划数】；否则正常插入随机数
        IF (v_current_sum + v_random_num) > v_plan_qty THEN
            v_real_insert_num = v_plan_qty - v_current_sum;  -- 超量 → 实际插入：差额，刚好达标
        ELSE
            v_real_insert_num = v_random_num;                -- 不超量 → 实际插入：随机数
        END IF;
        
        -- ========== 3. 随机生成员工+合理执行时间 ==========
        v_operator = 'E00' || floor(random()*5 + 1)::TEXT;  -- 仅从你的5个员工随机：E001~005
        SELECT t.plan_start + (random()*(t.plan_end - t.plan_start))::interval 
        INTO v_exec_time FROM task_ t WHERE t.task_id = v_task_id;
        
        -- ========== 4. 插入最终数据 ==========
        INSERT INTO task_exec_ (task_id, exec_time, completed_quantity, operator_id)
        VALUES (v_task_id, v_exec_time, v_real_insert_num, v_operator);
        
    END LOOP;
END;
$$;


ALTER FUNCTION public.auto_insert_task_exec_safe(insert_count integer) OWNER TO u;

--
-- Name: calculate_on_time_rate_(timestamp without time zone, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: u
--

CREATE PROCEDURE calculate_on_time_rate_(
    p_start_date TIMESTAMP,
    p_end_date TIMESTAMP,
    o_on_time_rate OUT NUMERIC(5,2),
    o_total_task OUT INT,
    o_on_time_task OUT INT
)  NOT SHIPPABLE
 AS  DECLARE BEGIN
    -- 初始化返回值
    o_total_task := 0;
    o_on_time_task := 0;
    o_on_time_rate := 0.00;
    
    -- 统计指定时间段内的已完成任务
    SELECT 
        COUNT(DISTINCT task_id),
        COUNT(DISTINCT CASE WHEN actual_end <= plan_end THEN task_id END)
    INTO o_total_task, o_on_time_task
    FROM task_
    WHERE status = '已完成' 
      AND plan_end BETWEEN p_start_date AND p_end_date;
    
    -- 计算按期完成率
    IF o_total_task > 0 THEN
        o_on_time_rate := ROUND((o_on_time_task::NUMERIC / o_total_task::NUMERIC)*100,2);
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        o_on_time_rate := 0.00;
        o_total_task := 0;
        o_on_time_task := 0;
END;
/


ALTER PROCEDURE public.calculate_on_time_rate_(p_start_date timestamp without time zone, p_end_date timestamp without time zone, OUT o_on_time_rate numeric, OUT o_total_task integer, OUT o_on_time_task integer) OWNER TO u;

--
-- Name: check_quantity_check_(); Type: FUNCTION; Schema: public; Owner: u
--

CREATE FUNCTION check_quantity_check_() RETURNS trigger
    LANGUAGE plpgsql NOT SHIPPABLE
 AS $$
DECLARE
    total_completed INT;
    plan_qty INT;
BEGIN
    -- 只保留数据库约束无法实现的部分
    
    -- 1. 如果是 DELETE 操作，直接返回
    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    END IF;
    
    -- 2. 计算累计产量（排除当前正在操作的记录）
    SELECT COALESCE(SUM(completed_quantity), 0) INTO total_completed 
    FROM task_exec_ 
    WHERE task_id = NEW.task_id
      AND exec_id != COALESCE(NEW.exec_id, -1);
    
    -- 如果是 UPDATE 且 task_id 没变，减去旧值
    IF TG_OP = 'UPDATE' AND OLD.task_id = NEW.task_id THEN
        total_completed := total_completed - OLD.completed_quantity;
    END IF;
    
    -- 加上新值
    total_completed := total_completed + NEW.completed_quantity;
    
    -- 3. 获取任务计划产量
    SELECT plan_quantity INTO plan_qty 
    FROM task_ 
    WHERE task_id = NEW.task_id;
    
    -- 4. 校验累计完成产量 ≤ 计划产量
    IF total_completed > plan_qty THEN
        RAISE EXCEPTION '任务 % 累计完成产量 % 超过计划产量 %，禁止操作', 
            NEW.task_id, total_completed, plan_qty;
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.check_quantity_check_() OWNER TO u;

--
-- Name: check_task_completion(); Type: FUNCTION; Schema: public; Owner: u
--

CREATE FUNCTION check_task_completion() RETURNS trigger
    LANGUAGE plpgsql NOT SHIPPABLE
 AS $$
DECLARE
    total_completed INT;
    plan_qty INT;
BEGIN
    -- 获取任务计划产量和累计完成产量
    SELECT plan_quantity INTO plan_qty FROM task_ WHERE task_id = NEW.task_id;
    SELECT COALESCE(SUM(completed_quantity), 0) INTO total_completed FROM task_exec_ WHERE task_id = NEW.task_id;
    
    -- 累计产量达标（等于/超过计划），自动更新为已完成并赋值实际结束时间
    IF total_completed >= plan_qty AND NEW.status <> '已完成' THEN
        UPDATE task_ SET status = '已完成', actual_end = CURRENT_TIMESTAMP WHERE task_id = NEW.task_id;
    END IF;
    
    -- 手动标记已完成时，校验产量是否达标
    IF NEW.status = '已完成' AND total_completed < plan_qty THEN
        RAISE EXCEPTION '任务%累计产量未达标，禁止标记为已完成', NEW.task_id;
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.check_task_completion() OWNER TO u;

--
-- Name: generate_production_report_(character varying, timestamp without time zone, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: u
--

CREATE PROCEDURE generate_production_report_(
    p_product_id VARCHAR(20),
    p_start_date TIMESTAMP,
    p_end_date TIMESTAMP,
    o_report_cursor OUT REFCURSOR
)  NOT SHIPPABLE
 AS  DECLARE BEGIN
    -- 打开游标返回生产趋势数据
    OPEN o_report_cursor FOR
        SELECT
            TRUNC(te.exec_time) AS stat_date,
            p.product_name,
            p.specifications,
            SUM(te.completed_quantity) AS daily_output,
            EXTRACT(WEEK FROM te.exec_time) AS week_number,
            SUM(SUM(te.completed_quantity)) OVER(PARTITION BY EXTRACT(WEEK FROM te.exec_time)) AS weekly_output
        FROM task_exec_ te
        LEFT JOIN task_ t ON te.task_id = t.task_id
        LEFT JOIN product_ p ON t.product_id = p.product_id
        WHERE t.product_id = p_product_id
          AND te.exec_time BETWEEN p_start_date AND p_end_date
        GROUP BY TRUNC(te.exec_time), p.product_name, p.specifications, EXTRACT(WEEK FROM te.exec_time)
        ORDER BY stat_date;
EXCEPTION
    WHEN OTHERS THEN
        OPEN o_report_cursor FOR SELECT NULL AS stat_date, NULL AS product_name, NULL AS specifications, 0 AS daily_output, 0 AS week_number,0 AS weekly_output;
END;
/


ALTER PROCEDURE public.generate_production_report_(p_product_id character varying, p_start_date timestamp without time zone, p_end_date timestamp without time zone, OUT o_report_cursor refcursor) OWNER TO u;

--
-- Name: report_production_progress_(character varying, integer, character varying); Type: PROCEDURE; Schema: public; Owner: u
--

CREATE PROCEDURE report_production_progress_(
    p_task_id VARCHAR(20),
    p_completed_quantity INT,
    p_operator_id VARCHAR(20),
    o_result OUT VARCHAR(200)
)  NOT SHIPPABLE
 AS  DECLARE BEGIN
    -- 参数合法性校验
    IF NOT EXISTS (SELECT 1 FROM task_ WHERE task_id = p_task_id) THEN
        o_result := '上报失败：任务ID【'||p_task_id||'】不存在！';
        RETURN;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM employee_ WHERE emp_id = p_operator_id) THEN
        o_result := '上报失败：操作员ID【'||p_operator_id||'】不存在！';
        RETURN;
    END IF;
    IF p_completed_quantity < 0 THEN
        o_result := '上报失败：完成产量不能为负数！';
        RETURN;
    END IF;
    IF EXISTS (SELECT 1 FROM task_ WHERE task_id = p_task_id AND status IN ('已完成','已取消')) THEN
        o_result := '上报失败：任务【'||p_task_id||'】已完成/已取消，禁止上报进度！';
        RETURN;
    END IF;
    
    -- 插入执行记录（自动触发产量校验触发器）
    INSERT INTO task_exec_ (task_id, completed_quantity, operator_id)
    VALUES (p_task_id, p_completed_quantity, p_operator_id);
    
    -- 自动更新任务状态为执行中
    UPDATE task_ SET status = '执行中' WHERE task_id = p_task_id;
    
    o_result := '进度上报成功，任务ID：'||p_task_id||'，本次完成产量：'||p_completed_quantity;
EXCEPTION
    WHEN OTHERS THEN
        o_result := '上报失败：' || SQLERRM;
END;
/


ALTER PROCEDURE public.report_production_progress_(p_task_id character varying, p_completed_quantity integer, p_operator_id character varying, OUT o_result character varying) OWNER TO u;

--
-- Name: update_task_quantity_trigger_(); Type: FUNCTION; Schema: public; Owner: u
--

CREATE FUNCTION update_task_quantity_trigger_() RETURNS trigger
    LANGUAGE plpgsql NOT SHIPPABLE
 AS $$
DECLARE
    total_completed INT;
    plan_qty INT;
    first_exec_time TIMESTAMP;
    last_exec_time TIMESTAMP;
    affected_task_id VARCHAR(20);
    current_status VARCHAR(10);
BEGIN
    -- 1. 确定受影响的任务ID
    IF TG_OP = 'DELETE' THEN
        affected_task_id := OLD.task_id;
    ELSE
        affected_task_id := NEW.task_id;
    END IF;
    
    -- 2. 自动重新计算任务累计完成产量
    SELECT COALESCE(SUM(completed_quantity), 0) INTO total_completed 
    FROM task_exec_ 
    WHERE task_id = affected_task_id;
    
    -- 3. 获取任务计划产量+当前状态【必须获取status】
    SELECT plan_quantity, status INTO plan_qty, current_status
    FROM task_ 
    WHERE task_id = affected_task_id;
    
    -- 4. 校验累计完成产量≤计划产量，超量则抛异常回滚
    IF total_completed > plan_qty THEN
        RAISE EXCEPTION '任务 % 累计完成产量 % 超过计划产量 %，禁止操作', 
            affected_task_id, total_completed, plan_qty;
    END IF;

    -- ================ 核心新增：状态判断 【重中之重】 ================
    -- 如果任务已经是【已完成/已取消】，直接跳过所有更新操作，避免触发拦截触发器
    IF current_status IN ('已完成', '已取消') THEN
        IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
    END IF;
    
    -- 5. 获取第一条和最后一条执行记录的时间
    SELECT MIN(exec_time), MAX(exec_time) 
    INTO first_exec_time, last_exec_time
    FROM task_exec_ 
    WHERE task_id = affected_task_id;
    
    -- 6. 更新任务的时间【已删除status更新的冗余逻辑】
    UPDATE task_ 
    SET 
        actual_start = first_exec_time,
        actual_end = CASE WHEN total_completed >= plan_qty THEN last_exec_time ELSE actual_end END
    WHERE task_id = affected_task_id;
    
    -- 7. 返回适当的值
    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    ELSE
        RETURN NEW;
    END IF;
END;
$$;


ALTER FUNCTION public.update_task_quantity_trigger_() OWNER TO u;

--
-- Name: update_task_status(); Type: FUNCTION; Schema: public; Owner: u
--

CREATE FUNCTION update_task_status() RETURNS trigger
    LANGUAGE plpgsql NOT SHIPPABLE
 AS $$
BEGIN
    -- ========== 核心优化：精准拦截【人工手动修改】，彻底放行【系统自动更新】 ==========
    -- 已完成/已取消的任务，禁止修改除了状态和时间之外的任何字段
    IF OLD.status IN ('已完成', '已取消') THEN
        -- 只放行对 status、actual_start、actual_end 的修改，其他任何字段修改都拦截
        IF OLD.task_id <> NEW.task_id 
           OR OLD.plan_quantity <> NEW.plan_quantity 
           OR OLD.product_id <> NEW.product_id  -- 替换成你表中实际存在的字段
           OR OLD.plan_start <> NEW.plan_start
           OR OLD.plan_end <> NEW.plan_end
        THEN
            RAISE EXCEPTION '任务%当前状态为【%】，禁止修改任何信息！', OLD.task_id, OLD.status;
        END IF;
    END IF;

    IF OLD.status <> NEW.status THEN
        -- 未开始的任务，修改状态时的合法规则
        IF OLD.status = '未开始' AND NEW.status NOT IN ('执行中', '已取消') THEN
            RAISE EXCEPTION '任务%状态为未开始，仅可修改为执行中或已取消', OLD.task_id;
        END IF;
        -- 执行中的任务，修改状态时的合法规则
        IF OLD.status = '执行中' AND NEW.status NOT IN ('已完成', '已取消') THEN
            RAISE EXCEPTION '任务%状态为执行中，仅可修改为已完成或已取消', OLD.task_id;
        END IF;

        IF NEW.status = '执行中' AND NEW.actual_start IS NULL THEN
            RAISE EXCEPTION '任务%修改为执行中，必须填写实际开始时间', OLD.task_id;
        END IF;
        IF NEW.status = '已完成' THEN
            IF NEW.actual_start IS NULL OR NEW.actual_end IS NULL THEN
                RAISE EXCEPTION '任务%修改为已完成，必须填写实际开始和结束时间', OLD.task_id;
            ELSIF NEW.actual_end < NEW.actual_start THEN
                RAISE EXCEPTION '任务%实际结束时间不能早于实际开始时间', OLD.task_id;
            END IF;
        END IF;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_task_status() OWNER TO u;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: employee_; Type: TABLE; Schema: public; Owner: u; Tablespace: 
--

CREATE TABLE employee_ (
    emp_id character varying(20) NOT NULL,
    emp_name character varying(50) NOT NULL
)
WITH (orientation=row, compression=no);


ALTER TABLE public.employee_ OWNER TO u;

--
-- Name: product_; Type: TABLE; Schema: public; Owner: u; Tablespace: 
--

CREATE TABLE product_ (
    product_id character varying(20) NOT NULL,
    product_name character varying(255) NOT NULL,
    specifications character varying(255) NOT NULL
)
WITH (orientation=row, compression=no);


ALTER TABLE public.product_ OWNER TO u;

--
-- Name: task_; Type: TABLE; Schema: public; Owner: u; Tablespace: 
--

CREATE TABLE task_ (
    task_id character varying(20) NOT NULL,
    product_id character varying(20) NOT NULL,
    plan_quantity integer NOT NULL,
    plan_start timestamp without time zone NOT NULL,
    plan_end timestamp without time zone NOT NULL,
    actual_start timestamp without time zone,
    actual_end timestamp without time zone,
    order_id character varying(20) NOT NULL,
    status character varying(10) DEFAULT '未开始'::character varying NOT NULL,
    CONSTRAINT task__check CHECK ((plan_end >= plan_start)),
    CONSTRAINT task__check1 CHECK (((actual_start >= plan_start) OR (actual_start IS NULL))),
    CONSTRAINT task__check2 CHECK (((((actual_start IS NULL) AND (actual_end IS NULL)) OR ((actual_start IS NOT NULL) AND (actual_end IS NULL))) OR (((actual_start IS NOT NULL) AND (actual_end IS NOT NULL)) AND (actual_end >= actual_start)))),
    CONSTRAINT task__plan_quantity_check CHECK ((plan_quantity > 0)),
    CONSTRAINT task__status_check CHECK (((status)::text = ANY ((ARRAY['未开始'::character varying, '执行中'::character varying, '已完成'::character varying, '已取消'::character varying])::text[])))
)
WITH (orientation=row, compression=no);


ALTER TABLE public.task_ OWNER TO u;

--
-- Name: task_exec_; Type: TABLE; Schema: public; Owner: u; Tablespace: 
--

CREATE TABLE task_exec_ (
    exec_id bigint NOT NULL,
    task_id character varying(20) NOT NULL,
    exec_time timestamp without time zone DEFAULT pg_systimestamp() NOT NULL,
    completed_quantity integer NOT NULL,
    operator_id character varying(20) NOT NULL,
    CONSTRAINT task_exec__completed_quantity_check CHECK ((completed_quantity >= 0))
)
WITH (orientation=row, compression=no);


ALTER TABLE public.task_exec_ OWNER TO u;

--
-- Name: multi_task_comparison_view_; Type: VIEW; Schema: public; Owner: u
--

CREATE VIEW multi_task_comparison_view_("任务编号","产品名称","计划产量",actual_quantity,completion_rate,"任务状态",operator_name,last_update_time,remaining_qty) AS
    SELECT t.task_id AS "任务编号", p.product_name AS "产品名称", t.plan_quantity AS "计划产量", COALESCE(sum(te.completed_quantity), (0)::bigint) AS actual_quantity, ((round(CASE WHEN (t.plan_quantity = 0) THEN (0)::numeric ELSE (((COALESCE(sum(te.completed_quantity), (0)::bigint))::numeric * 100.0) / (t.plan_quantity)::numeric) END, 2))::text || '%'::text) AS completion_rate, t.status AS "任务状态", (SELECT e.emp_name FROM (task_exec_ te2 LEFT JOIN employee_ e ON (((te2.operator_id)::text = (e.emp_id)::text))) WHERE ((te2.task_id)::text = (t.task_id)::text) ORDER BY te2.exec_time DESC LIMIT 1) AS operator_name, max(te.exec_time) AS last_update_time, (t.plan_quantity - COALESCE(sum(te.completed_quantity), (0)::bigint)) AS remaining_qty FROM ((task_ t LEFT JOIN product_ p ON (((t.product_id)::text = (p.product_id)::text))) LEFT JOIN task_exec_ te ON (((t.task_id)::text = (te.task_id)::text))) GROUP BY t.task_id, p.product_name, t.plan_quantity, t.status ORDER BY t.task_id;


ALTER VIEW public.multi_task_comparison_view_ OWNER TO u;

--
-- Name: on_time_completion_view_; Type: VIEW; Schema: public; Owner: u
--

CREATE VIEW on_time_completion_view_("任务编号","产品名称","任务状态","计划结束时间","实际结束时间",is_on_time,completion_days,delay_days) AS
    SELECT t.task_id AS "任务编号", p.product_name AS "产品名称", t.status AS "任务状态", t.plan_end AS "计划结束时间", t.actual_end AS "实际结束时间", (((t.status)::text = '已完成'::text) AND (t.actual_end <= t.plan_end)) AS is_on_time, COALESCE(date_part('day'::text, (t.actual_end - t.plan_start)), (0)::double precision) AS completion_days, CASE WHEN (((t.status)::text = '已完成'::text) AND (t.actual_end > t.plan_end)) THEN date_part('day'::text, (t.actual_end - t.plan_end)) ELSE (0)::double precision END AS delay_days FROM (task_ t LEFT JOIN product_ p ON (((t.product_id)::text = (p.product_id)::text))) ORDER BY t.task_id;


ALTER VIEW public.on_time_completion_view_ OWNER TO u;

--
-- Name: product_production_summary_view_; Type: VIEW; Schema: public; Owner: u
--

CREATE VIEW product_production_summary_view_("产品编号","产品名称","产品规格",total_plan_qty,total_completed_qty,completion_rate,task_count) AS
    SELECT p.product_id AS "产品编号", p.product_name AS "产品名称", p.specifications AS "产品规格", COALESCE(sum(t.plan_quantity), (0)::bigint) AS total_plan_qty, COALESCE(sum(te.completed_quantity), (0)::bigint) AS total_completed_qty, ((round(CASE WHEN (sum(t.plan_quantity) = 0) THEN (0)::numeric ELSE (((sum(te.completed_quantity))::numeric * 100.0) / (sum(t.plan_quantity))::numeric) END, 2))::text || '%'::text) AS completion_rate, count(DISTINCT t.task_id) AS task_count FROM ((product_ p LEFT JOIN task_ t ON (((p.product_id)::text = (t.product_id)::text))) LEFT JOIN task_exec_ te ON (((t.task_id)::text = (te.task_id)::text))) GROUP BY p.product_id, p.product_name, p.specifications ORDER BY p.product_id;


ALTER VIEW public.product_production_summary_view_ OWNER TO u;

--
-- Name: production_trend_view_; Type: VIEW; Schema: public; Owner: u
--

CREATE VIEW production_trend_view_(stat_date,"产品编号","产品名称",daily_output,week_number,weekly_output,avg_daily_output) AS
    SELECT trunc((te.exec_time)::timestamp with time zone) AS stat_date, t.product_id AS "产品编号", p.product_name AS "产品名称", sum(te.completed_quantity) AS daily_output, date_part('week'::text, te.exec_time) AS week_number, sum(sum(te.completed_quantity)) OVER (PARTITION BY t.product_id, date_part('week'::text, te.exec_time)) AS weekly_output, round(avg(sum(te.completed_quantity)) OVER (PARTITION BY t.product_id, date_part('week'::text, te.exec_time)), 2) AS avg_daily_output FROM ((task_exec_ te LEFT JOIN task_ t ON (((te.task_id)::text = (t.task_id)::text))) LEFT JOIN product_ p ON (((t.product_id)::text = (p.product_id)::text))) GROUP BY trunc((te.exec_time)::timestamp with time zone), t.product_id, p.product_name, date_part('week'::text, te.exec_time) ORDER BY trunc((te.exec_time)::timestamp with time zone), t.product_id;


ALTER VIEW public.production_trend_view_ OWNER TO u;

--
-- Name: task_exec__exec_id_seq; Type: SEQUENCE; Schema: public; Owner: u
--

CREATE  SEQUENCE task_exec__exec_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_exec__exec_id_seq OWNER TO u;

--
-- Name: task_exec__exec_id_seq; Type: LARGE SEQUENCE OWNED BY; Schema: public; Owner: u
--

ALTER  SEQUENCE task_exec__exec_id_seq OWNED BY task_exec_.exec_id;


--
-- Name: task_progress_view_; Type: VIEW; Schema: public; Owner: u
--

CREATE VIEW task_progress_view_("任务编号","产品编号","产品名称","计划产量",total_completed,progress_rate,"任务状态","计划开始时间","计划结束时间","所属订单") AS
    SELECT t.task_id AS "任务编号", t.product_id AS "产品编号", p.product_name AS "产品名称", t.plan_quantity AS "计划产量", COALESCE(sum(te.completed_quantity), (0)::bigint) AS total_completed, ((round(CASE WHEN (t.plan_quantity = 0) THEN (0)::numeric ELSE (((COALESCE(sum(te.completed_quantity), (0)::bigint))::numeric * 100.0) / (t.plan_quantity)::numeric) END, 2))::text || '%'::text) AS progress_rate, t.status AS "任务状态", t.plan_start AS "计划开始时间", t.plan_end AS "计划结束时间", t.order_id AS "所属订单" FROM ((task_ t LEFT JOIN product_ p ON (((t.product_id)::text = (p.product_id)::text))) LEFT JOIN task_exec_ te ON (((t.task_id)::text = (te.task_id)::text))) GROUP BY t.task_id, t.product_id, p.product_name, t.plan_quantity, t.status, t.plan_start, t.plan_end, t.order_id ORDER BY t.task_id;


ALTER VIEW public.task_progress_view_ OWNER TO u;

--
-- Name: exec_id; Type: DEFAULT; Schema: public; Owner: u
--

ALTER TABLE task_exec_ ALTER COLUMN exec_id SET DEFAULT nextval('task_exec__exec_id_seq'::regclass);


--
-- Data for Name: employee_; Type: TABLE DATA; Schema: public; Owner: u
--

COPY employee_ (emp_id, emp_name) FROM stdin;
E001	张三
E002	李四
E003	王五
E004	赵六
E005	孙七
\.
;

--
-- Data for Name: product_; Type: TABLE DATA; Schema: public; Owner: u
--

COPY product_ (product_id, product_name, specifications) FROM stdin;
P001	工业级不锈钢轴承	内径20mm，外径50mm，精度P5
P002	高强度铝合金型材	6063-T5，截面20*40mm，长度3m
P003	精密数控加工齿轮	模数2.0，齿数28，齿宽15mm
P004	耐高温硅胶密封圈	外径30mm，内径20mm，耐温200℃
\.
;

--
-- Data for Name: task_; Type: TABLE DATA; Schema: public; Owner: u
--

COPY task_ (task_id, product_id, plan_quantity, plan_start, plan_end, actual_start, actual_end, order_id, status) FROM stdin;
T031	P001	100	2026-01-18 09:25:00	2026-01-25 09:25:00	2026-01-18 21:42:53.005652	\N	O001	执行中
T032	P001	100	2026-01-19 09:13:00	2026-01-22 09:13:00	2026-01-19 09:14:09.449528	\N	O002	执行中
T035	P001	600	2026-01-19 09:29:00	2026-01-31 09:29:00	\N	\N	O005	未开始
T036	P001	600	2026-01-19 09:42:00	2026-01-31 09:42:00	2026-01-19 09:44:19.890266	\N	O005	执行中
T006	P002	490	2026-01-07 08:00:00	2026-01-17 18:00:00	2026-01-08 06:27:13.249865	2026-01-20 18:00:00	O006	已完成
T009	P001	510	2026-01-10 00:00:00	2026-01-20 10:00:00	2026-01-11 07:27:25.224004	2026-01-20 15:32:41.406739	O009	已完成
T013	P001	300	2026-01-14 00:00:00	2026-01-24 10:00:00	2026-01-14 18:07:56.360774	2026-01-27 18:00:00	O003	已完成
T026	P002	480	2026-02-07 08:00:00	2026-02-17 18:00:00	2026-02-08 17:54:06.10887	\N	O006	执行中
T025	P001	900	2026-02-06 08:00:00	2026-02-16 18:00:00	2026-02-06 18:40:10.899834	\N	O005	执行中
T010	P002	890	2026-01-11 08:00:00	2026-01-21 18:00:00	2026-01-11 17:55:19.587654	\N	O010	执行中
T017	P001	710	2026-01-18 08:00:00	2026-01-28 18:00:00	2026-01-21 04:22:59.235773	\N	O007	执行中
T022	P002	540	2026-02-03 08:00:00	2026-02-13 18:00:00	2026-02-04 01:41:12.555797	2026-02-13 02:48:29.722564	O002	已完成
T007	P003	680	2026-01-08 08:00:00	2026-01-18 18:00:00	2026-01-08 22:27:04.867014	2026-01-18 12:12:57.197954	O007	已完成
T005	P001	500	2026-01-06 00:00:00	2026-01-16 10:00:00	2026-01-07 13:34:11.961492	\N	O005	执行中
T003	P003	780	2026-01-04 08:00:00	2026-01-14 18:00:00	2026-01-05 16:47:55.431604	\N	O003	执行中
T029	P001	640	2026-02-10 08:00:00	2026-02-20 18:00:00	2026-02-10 17:52:30.595914	\N	O009	执行中
T008	P004	730	2026-01-09 08:00:00	2026-01-19 18:00:00	2026-01-09 10:06:25.054916	\N	O008	执行中
T024	P004	660	2026-02-05 08:00:00	2026-02-15 18:00:00	2026-02-05 09:51:51.941818	\N	O004	执行中
T016	P004	630	2026-01-17 08:00:00	2026-01-27 18:00:00	2026-01-17 20:02:02.224449	\N	O006	执行中
T015	P003	950	2026-01-16 08:00:00	2026-01-26 18:00:00	2026-01-17 03:25:32.167372	\N	O005	执行中
T018	P002	820	2026-01-19 08:00:00	2026-01-29 18:00:00	2026-01-19 15:51:20.097479	\N	O008	执行中
T021	P001	760	2026-02-02 08:00:00	2026-02-12 18:00:00	2026-02-02 09:45:23.066354	\N	O001	执行中
T020	P004	690	2026-01-21 08:00:00	2026-02-01 18:00:00	2026-01-21 18:12:19.42135	\N	O010	执行中
T011	P003	650	2026-01-12 08:00:00	2026-01-22 18:00:00	2026-01-12 08:58:38.022644	\N	O001	执行中
T012	P004	790	2026-01-13 08:00:00	2026-01-23 18:00:00	2026-01-13 11:09:01.397278	\N	O002	执行中
T002	P002	620	2026-01-03 08:00:00	2026-01-13 18:00:00	2026-01-04 04:59:16.628919	\N	O002	执行中
T030	P002	870	2026-02-11 08:00:00	2026-02-21 18:00:00	2026-02-11 13:09:24.937357	\N	O010	执行中
T023	P003	810	2026-02-04 08:00:00	2026-02-14 18:00:00	2026-02-04 23:05:46.217495	\N	O003	执行中
T028	P004	590	2026-02-09 08:00:00	2026-02-19 18:00:00	2026-02-09 08:19:16.319166	\N	O008	执行中
T027	P003	750	2026-02-08 08:00:00	2026-02-18 18:00:00	2026-02-08 14:26:21.545874	\N	O007	执行中
T019	P003	530	2026-01-20 08:00:00	2026-01-30 18:00:00	2026-01-20 09:39:23.340634	\N	O009	执行中
T004	P004	560	2026-01-05 08:00:00	2026-01-15 18:00:00	2026-01-07 20:45:59.308057	\N	O004	执行中
T014	P002	580	2026-01-15 08:00:00	2026-01-25 18:00:00	2026-01-17 06:52:08.646264	\N	O004	执行中
T001	P001	660	2026-01-01 00:00:00	2026-01-11 10:00:00	2026-01-02 11:04:00.753079	2026-01-19 10:07:15.529695	O001	已完成
\.
;

--
-- Data for Name: task_exec_; Type: TABLE DATA; Schema: public; Owner: u
--

COPY task_exec_ (exec_id, task_id, exec_time, completed_quantity, operator_id) FROM stdin;
9469	T031	2026-01-18 21:42:53.005652	62	E001
9470	T001	2026-01-18 22:55:41.982619	50	E001
9471	T032	2026-01-19 09:14:09.449528	20	E001
9486	T001	2026-01-19 10:07:15.514095	86	E001
9472	T032	2026-01-19 09:31:00.766476	50	E001
9466	T001	2026-01-18 20:35:26.546017	20	E001
9473	T036	2026-01-19 09:44:19.890266	50	E001
8914	T017	2026-01-23 00:18:07.885408	6	E001
8915	T020	2026-01-28 05:36:49.005426	40	E003
8916	T024	2026-02-15 03:49:06.001706	24	E001
8917	T021	2026-02-08 11:53:30.479709	5	E005
8918	T018	2026-01-27 07:16:12.062692	29	E001
8919	T019	2026-01-24 21:20:31.060375	18	E001
8920	T028	2026-02-19 03:06:55.454009	6	E005
8921	T017	2026-01-25 09:12:13.727057	47	E001
8922	T015	2026-01-25 22:54:12.116756	34	E001
8923	T008	2026-01-14 23:08:32.499769	16	E002
8924	T014	2026-01-17 06:52:08.646264	6	E003
8925	T011	2026-01-13 21:47:34.631509	8	E002
8926	T022	2026-02-10 20:24:12.066422	38	E005
8927	T002	2026-01-07 12:49:05.311004	15	E003
8928	T008	2026-01-09 20:21:18.764897	39	E002
8929	T018	2026-01-27 04:13:45.279128	12	E005
8930	T008	2026-01-17 09:19:02.110056	36	E002
8931	T027	2026-02-08 14:26:21.545874	5	E001
8932	T002	2026-01-06 17:28:01.981861	4	E003
8933	T009	2026-01-18 08:02:59.471356	17	E002
8934	T005	2026-01-15 22:45:42.493272	49	E004
8935	T008	2026-01-18 20:02:17.674446	48	E001
8936	T013	2026-01-15 10:44:55.466088	46	E005
8937	T008	2026-01-15 20:44:24.529339	23	E002
8938	T002	2026-01-05 21:48:53.082682	48	E005
8939	T026	2026-02-14 04:22:16.578243	43	E002
8940	T023	2026-02-05 15:08:48.874473	30	E003
8941	T006	2026-01-10 03:56:33.663001	32	E004
8942	T006	2026-01-11 14:10:13.851451	16	E003
8943	T023	2026-02-06 10:58:10.720019	44	E005
8944	T004	2026-01-10 00:18:18.293637	25	E001
8945	T018	2026-01-26 23:26:41.96009	34	E005
8946	T022	2026-02-11 20:49:03.88249	45	E004
8947	T013	2026-01-21 10:06:49.534073	37	E004
8948	T008	2026-01-13 13:26:01.663899	6	E003
8949	T019	2026-01-27 16:04:16.909443	46	E004
8950	T009	2026-01-13 14:56:37.676042	20	E003
8951	T005	2026-01-12 13:29:46.960481	32	E001
8952	T011	2026-01-13 10:44:32.039506	11	E005
8953	T017	2026-01-27 11:49:26.526252	12	E004
8954	T019	2026-01-22 09:44:00.137306	8	E001
8955	T012	2026-01-22 14:51:23.519693	21	E003
8956	T025	2026-02-08 01:34:28.55091	16	E004
8957	T016	2026-01-20 19:35:45.334229	2	E003
8958	T022	2026-02-08 14:35:20.770871	21	E002
8959	T017	2026-01-24 05:57:23.421831	35	E002
8960	T007	2026-01-11 19:40:36.039586	17	E001
8961	T029	2026-02-20 09:54:13.976486	19	E004
8962	T010	2026-01-12 21:36:11.010192	2	E003
8963	T028	2026-02-12 05:39:35.47878	10	E001
8964	T014	2026-01-24 23:13:26.925922	45	E002
8965	T009	2026-01-11 19:32:27.860956	3	E004
8966	T021	2026-02-03 00:02:46.378484	16	E001
8967	T001	2026-01-03 03:18:04.018022	8	E003
8968	T021	2026-02-08 15:35:19.361119	18	E001
8969	T014	2026-01-20 21:16:32.278726	49	E004
8970	T022	2026-02-05 00:04:19.988749	42	E003
8971	T018	2026-01-25 15:18:02.176039	4	E003
8972	T008	2026-01-11 02:25:13.019914	51	E002
8973	T028	2026-02-09 08:57:56.614784	38	E003
8974	T023	2026-02-12 05:45:40.913817	2	E002
8975	T006	2026-01-12 04:23:06.880314	15	E005
8976	T012	2026-01-14 14:00:29.405074	43	E001
8977	T011	2026-01-14 17:14:11.942613	35	E001
8978	T015	2026-01-17 12:43:37.807678	25	E001
8979	T019	2026-01-21 21:40:27.013631	38	E004
8980	T013	2026-01-24 02:29:01.157018	47	E005
8981	T027	2026-02-09 00:28:20.169116	10	E004
8982	T007	2026-01-17 00:35:35.055502	34	E004
8983	T012	2026-01-18 13:09:10.791202	25	E001
8984	T011	2026-01-20 10:04:41.03438	21	E005
8985	T008	2026-01-10 18:53:27.316755	11	E005
8986	T029	2026-02-18 15:11:58.245782	29	E005
8987	T017	2026-01-26 00:06:04.743576	16	E003
8988	T020	2026-01-27 00:00:43.270361	51	E002
8989	T024	2026-02-07 14:15:59.221659	31	E001
8990	T008	2026-01-17 07:03:23.147547	5	E005
8991	T023	2026-02-14 07:17:36.928029	17	E002
8992	T002	2026-01-11 15:40:44.748102	36	E004
8993	T010	2026-01-12 23:03:38.227422	3	E002
8994	T030	2026-02-13 07:36:15.201177	3	E003
8995	T015	2026-01-26 12:14:05.66092	38	E005
8996	T023	2026-02-12 18:45:45.54285	18	E004
8997	T025	2026-02-07 19:46:40.087608	8	E005
8998	T013	2026-01-24 04:44:05.011506	28	E003
8999	T030	2026-02-13 16:19:19.14045	21	E005
9000	T014	2026-01-22 02:38:08.829575	51	E005
9001	T007	2026-01-15 10:56:29.594855	49	E004
9002	T010	2026-01-14 10:51:22.10802	46	E004
9003	T006	2026-01-11 18:10:10.389571	19	E003
9004	T025	2026-02-16 17:02:14.875548	15	E005
9005	T019	2026-01-22 04:42:42.154996	7	E005
9006	T022	2026-02-10 03:49:19.440254	38	E004
9007	T011	2026-01-12 08:58:38.022644	8	E003
9008	T003	2026-01-11 07:10:31.800257	11	E001
9009	T006	2026-01-13 21:34:39.951274	8	E004
9010	T025	2026-02-10 17:12:02.406411	9	E003
9011	T015	2026-01-25 17:49:40.919844	37	E005
9012	T021	2026-02-04 13:35:17.936621	27	E005
9013	T012	2026-01-13 23:19:41.249929	40	E002
9014	T009	2026-01-20 04:42:28.786001	38	E002
9015	T002	2026-01-04 07:20:01.067793	10	E002
9016	T021	2026-02-11 12:46:27.921896	5	E005
9017	T012	2026-01-23 11:26:08.064713	41	E003
9018	T016	2026-01-23 12:53:52.440048	43	E005
9019	T015	2026-01-25 07:43:53.071667	36	E004
9020	T008	2026-01-15 04:52:16.762189	30	E005
9021	T027	2026-02-15 22:43:41.627241	10	E002
9022	T006	2026-01-14 03:16:29.22027	46	E002
9023	T029	2026-02-17 06:05:03.227806	24	E002
9024	T007	2026-01-16 20:47:59.887498	40	E003
9025	T006	2026-01-09 08:37:30.156936	4	E005
9026	T021	2026-02-05 01:24:55.807835	32	E003
9027	T018	2026-01-19 15:51:20.097479	6	E002
9028	T010	2026-01-14 18:30:24.945868	17	E004
9029	T026	2026-02-12 19:58:45.088776	50	E005
9030	T012	2026-01-13 11:09:01.397278	22	E002
9031	T027	2026-02-09 22:04:59.230382	48	E003
9032	T026	2026-02-14 12:56:49.255789	2	E003
9033	T002	2026-01-08 17:38:48.476621	48	E004
9034	T012	2026-01-23 10:42:50.856158	30	E002
9035	T002	2026-01-13 14:26:06.66922	43	E004
9036	T020	2026-01-28 08:38:42.918987	17	E003
9037	T025	2026-02-11 10:01:06.509889	47	E002
9038	T009	2026-01-20 15:32:41.406739	1	E003
9039	T013	2026-01-15 09:25:21.036811	13	E004
9040	T022	2026-02-06 08:21:56.588436	26	E003
9041	T023	2026-02-06 15:56:05.280245	4	E003
9042	T012	2026-01-17 12:15:00.653433	21	E004
9043	T023	2026-02-09 18:17:47.02132	37	E001
9044	T028	2026-02-17 03:15:37.855042	39	E001
9045	T030	2026-02-21 06:27:10.840122	10	E001
9046	T021	2026-02-11 00:29:42.061708	21	E004
9047	T015	2026-01-25 09:04:20.857205	38	E003
9048	T001	2026-01-02 13:35:29.649248	38	E004
9049	T021	2026-02-04 16:55:14.548108	43	E005
9050	T022	2026-02-11 14:10:27.437329	32	E003
9051	T020	2026-01-31 03:11:00.610968	38	E004
9052	T018	2026-01-20 06:02:33.281529	35	E001
9053	T020	2026-01-25 17:52:44.054008	47	E001
9054	T020	2026-02-01 07:25:35.618168	35	E002
9055	T015	2026-01-17 03:25:32.167372	33	E005
9056	T028	2026-02-09 22:54:49.443414	12	E001
9057	T005	2026-01-14 15:51:47.04502	22	E005
9058	T020	2026-01-25 13:47:06.996264	13	E003
9059	T029	2026-02-18 14:35:22.755025	24	E002
9060	T030	2026-02-19 10:45:43.009728	30	E002
9061	T006	2026-01-08 06:27:13.249865	47	E004
9062	T012	2026-01-22 01:10:22.017376	31	E002
9063	T024	2026-02-06 16:57:58.204017	45	E004
9064	T022	2026-02-05 14:39:20.266414	28	E002
9065	T027	2026-02-13 16:15:52.61722	47	E001
9066	T018	2026-01-22 05:27:14.710904	32	E004
9067	T017	2026-01-27 11:48:38.741441	31	E002
9068	T021	2026-02-10 15:45:28.371589	21	E005
9069	T028	2026-02-14 22:29:17.585632	41	E004
9070	T011	2026-01-13 10:17:36.942739	5	E005
9071	T009	2026-01-19 06:43:19.45294	38	E005
9072	T023	2026-02-07 06:59:31.348966	26	E003
9073	T005	2026-01-11 12:20:36.903869	26	E005
9074	T030	2026-02-11 13:09:24.937357	38	E002
9075	T018	2026-01-25 08:18:41.435257	15	E004
9076	T016	2026-01-18 18:01:57.292108	50	E004
9077	T026	2026-02-08 17:54:06.10887	10	E001
9078	T009	2026-01-19 12:50:54.075401	50	E003
9079	T016	2026-01-23 16:09:38.661875	22	E002
9080	T029	2026-02-17 23:23:24.088082	12	E001
9081	T025	2026-02-12 20:43:47.905031	34	E004
9082	T029	2026-02-15 11:35:33.512527	19	E001
9083	T002	2026-01-05 00:01:35.684588	23	E002
9084	T019	2026-01-23 04:24:54.800006	27	E003
9085	T006	2026-01-12 22:03:13.577402	2	E004
9086	T027	2026-02-16 08:12:23.648877	19	E003
9087	T023	2026-02-11 17:45:13.955145	22	E001
9088	T012	2026-01-17 18:32:10.25727	1	E001
9089	T011	2026-01-18 00:19:31.157016	4	E005
9090	T012	2026-01-14 22:51:36.491496	17	E005
9091	T013	2026-01-22 08:42:54.368008	39	E004
9092	T004	2026-01-07 20:45:59.308057	42	E001
9093	T021	2026-02-03 06:40:09.748536	33	E003
9094	T001	2026-01-10 23:24:59.527278	40	E001
9095	T013	2026-01-16 18:33:47.651806	21	E005
9096	T006	2026-01-14 06:42:02.998422	17	E003
9097	T025	2026-02-09 15:05:40.517009	13	E003
9098	T013	2026-01-14 18:07:56.360774	33	E005
9099	T017	2026-01-25 13:56:41.946941	11	E003
9100	T008	2026-01-13 07:57:36.543798	32	E004
9101	T017	2026-01-24 15:51:24.092609	24	E003
9102	T011	2026-01-18 04:36:17.18976	45	E004
9103	T003	2026-01-08 13:53:20.419008	36	E003
9104	T009	2026-01-12 11:53:23.806806	3	E002
9105	T007	2026-01-08 22:27:04.867014	18	E001
9106	T027	2026-02-17 23:56:16.872755	27	E003
9107	T002	2026-01-07 08:42:15.496024	2	E005
9108	T001	2026-01-08 15:41:06.910028	45	E004
9109	T014	2026-01-19 03:42:00.611004	37	E003
9110	T028	2026-02-15 04:59:08.02823	42	E003
9111	T010	2026-01-20 18:16:27.426838	8	E005
9112	T008	2026-01-11 00:50:55.116249	21	E005
9113	T018	2026-01-20 15:51:09.305692	21	E004
9114	T006	2026-01-08 06:41:33.964032	11	E002
9115	T006	2026-01-09 07:01:12.766309	47	E005
9116	T008	2026-01-13 10:43:50.975044	9	E003
9117	T011	2026-01-14 22:55:14.855493	27	E004
9118	T023	2026-02-09 01:38:36.406041	36	E002
9119	T023	2026-02-08 18:58:25.203046	43	E005
9120	T026	2026-02-12 20:00:19.512172	19	E002
9121	T001	2026-01-05 12:14:12.697719	19	E003
9122	T003	2026-01-12 10:12:03.654189	44	E001
9123	T020	2026-01-21 18:12:19.42135	18	E005
9124	T001	2026-01-12 17:20:51.685774	37	E004
9125	T017	2026-01-28 00:53:41.026105	17	E004
9126	T021	2026-02-06 14:34:26.084489	26	E002
9127	T025	2026-02-13 06:22:14.908072	12	E005
9128	T021	2026-02-12 07:47:02.996285	16	E001
9129	T017	2026-01-28 03:01:11.716351	6	E002
9130	T019	2026-01-28 03:49:50.487575	2	E004
9131	T023	2026-02-10 23:06:32.70133	15	E005
9132	T008	2026-01-12 03:31:30.81207	51	E005
9133	T008	2026-01-12 03:10:57.796815	51	E004
9134	T028	2026-02-14 16:36:07.77986	24	E005
9135	T022	2026-02-11 08:46:09.80172	42	E003
9136	T003	2026-01-12 08:21:41.133028	48	E001
9137	T007	2026-01-10 15:30:14.802921	40	E001
9138	T023	2026-02-14 16:51:07.731795	37	E001
9139	T014	2026-01-22 19:14:58.747904	39	E003
9140	T003	2026-01-08 12:34:41.032432	39	E004
9141	T007	2026-01-13 13:38:47.320492	40	E002
9142	T024	2026-02-05 13:44:49.770347	25	E001
9143	T011	2026-01-22 03:29:01.676448	30	E004
9144	T014	2026-01-21 15:54:33.324551	18	E001
9145	T004	2026-01-11 05:45:47.749852	26	E003
9146	T013	2026-01-23 21:02:13.207063	18	E002
9147	T012	2026-01-13 22:40:49.466912	44	E001
9148	T009	2026-01-13 18:18:23.975629	50	E004
9149	T025	2026-02-09 14:12:52.621129	9	E005
9150	T022	2026-02-09 02:21:28.625958	49	E004
9151	T016	2026-01-23 04:13:13.091119	34	E002
9152	T016	2026-01-18 19:38:21.85052	28	E003
9153	T010	2026-01-17 18:19:55.889222	3	E002
9154	T025	2026-02-08 19:01:42.274755	5	E003
9155	T018	2026-01-28 08:36:32.946065	22	E003
9156	T009	2026-01-20 12:10:38.446862	12	E003
9157	T029	2026-02-16 04:24:34.379332	44	E004
9158	T006	2026-01-08 21:55:17.297057	6	E002
9159	T014	2026-01-21 20:21:59.250224	31	E004
9160	T006	2026-01-09 03:33:08.732065	44	E002
9161	T024	2026-02-10 12:21:36.15638	38	E005
9162	T011	2026-01-13 00:13:22.168052	12	E004
9163	T003	2026-01-14 06:53:30.082042	26	E005
9164	T004	2026-01-11 16:27:41.965444	22	E001
9165	T003	2026-01-08 04:51:28.895829	14	E003
9166	T007	2026-01-10 02:49:32.945023	51	E002
9167	T017	2026-01-27 08:59:45.416971	17	E003
9168	T002	2026-01-13 14:41:44.874501	38	E004
9169	T008	2026-01-17 12:16:45.574815	36	E002
9170	T015	2026-01-21 18:56:39.505483	34	E003
9171	T023	2026-02-14 06:16:10.06452	47	E002
9172	T026	2026-02-12 04:04:52.649257	11	E005
9173	T007	2026-01-10 12:10:54.788918	33	E003
9174	T011	2026-01-21 18:33:37.0615	21	E003
9175	T029	2026-02-10 21:08:52.770238	48	E002
9176	T019	2026-01-24 19:56:52.352265	46	E002
9177	T010	2026-01-12 13:29:50.992612	8	E001
9178	T026	2026-02-14 13:32:45.48655	3	E004
9179	T006	2026-01-11 07:21:12.455781	42	E003
9180	T007	2026-01-13 20:01:27.391757	46	E003
9181	T024	2026-02-13 18:54:06.779402	46	E003
9182	T027	2026-02-18 07:50:35.574342	45	E001
9183	T021	2026-02-06 18:15:17.657569	38	E003
9184	T029	2026-02-12 05:52:12.109914	4	E002
9185	T025	2026-02-11 08:08:08.176693	47	E003
9186	T009	2026-01-16 11:44:20.920647	44	E003
9187	T023	2026-02-04 23:05:46.217495	49	E005
9188	T028	2026-02-17 18:37:46.174682	48	E002
9189	T001	2026-01-03 15:17:10.683509	43	E001
9190	T027	2026-02-12 11:59:26.798778	1	E005
9191	T018	2026-01-21 06:28:06.21712	39	E003
9192	T003	2026-01-13 03:00:25.75092	33	E003
9193	T001	2026-01-12 16:25:06.665194	29	E001
9194	T013	2026-01-17 16:55:45.901368	27	E004
9195	T025	2026-02-13 23:54:05.541499	40	E004
9196	T016	2026-01-24 11:46:51.27933	21	E003
9197	T024	2026-02-14 14:26:14.519378	34	E004
9198	T016	2026-01-26 08:28:30.246929	13	E003
9199	T009	2026-01-12 00:04:28.379453	43	E003
9200	T006	2026-01-08 07:10:01.502296	19	E005
9201	T025	2026-02-11 03:57:50.041662	51	E005
9202	T010	2026-01-17 14:37:46.588239	46	E003
9203	T002	2026-01-05 15:29:36.890316	26	E002
9204	T026	2026-02-17 03:06:34.047886	3	E003
9205	T020	2026-01-23 05:18:00.881561	16	E003
9206	T023	2026-02-13 17:03:59.460831	11	E005
9207	T017	2026-01-24 00:11:22.28838	25	E003
9208	T017	2026-01-27 09:40:20.843897	50	E004
9209	T010	2026-01-11 17:55:19.587654	42	E001
9210	T021	2026-02-05 03:07:24.219635	26	E005
9211	T021	2026-02-08 23:11:51.17719	42	E002
9212	T009	2026-01-20 00:40:10.772252	51	E003
9213	T019	2026-01-29 09:01:20.841585	20	E001
9214	T007	2026-01-18 12:12:57.197954	46	E002
9215	T012	2026-01-20 21:29:32.213803	48	E002
9216	T027	2026-02-15 08:21:13.690765	33	E005
9217	T022	2026-02-04 01:41:12.555797	10	E002
9218	T029	2026-02-16 10:28:09.139386	40	E001
9219	T006	2026-01-12 10:22:59.545917	26	E004
9220	T025	2026-02-15 23:14:23.173941	34	E005
9221	T017	2026-01-21 22:44:30.233827	42	E001
9222	T006	2026-01-16 08:24:11.451059	13	E003
9223	T015	2026-01-23 11:52:40.057026	4	E005
9224	T026	2026-02-11 07:08:26.441195	18	E003
9225	T007	2026-01-15 06:43:34.5682	43	E005
9226	T024	2026-02-11 18:39:45.264099	46	E004
9227	T018	2026-01-24 11:28:40.742772	50	E002
9228	T002	2026-01-13 15:23:17.864985	25	E003
9229	T003	2026-01-05 17:17:20.356986	24	E003
9230	T020	2026-01-23 19:15:20.983471	12	E005
9231	T026	2026-02-11 23:36:12.581879	25	E004
9232	T013	2026-01-21 14:30:28.591802	34	E001
9233	T012	2026-01-18 16:58:38.949356	45	E004
9234	T023	2026-02-05 17:18:58.086206	49	E005
9235	T009	2026-01-20 11:10:42.610402	24	E004
9236	T021	2026-02-02 09:45:23.066354	48	E003
9237	T009	2026-01-13 00:43:12.903655	7	E005
9238	T014	2026-01-20 12:24:48.836637	21	E003
9239	T020	2026-01-24 16:50:02.839905	46	E004
9240	T016	2026-01-19 11:44:50.030926	45	E004
9241	T008	2026-01-11 18:12:04.064697	35	E005
9242	T005	2026-01-07 13:34:11.961492	46	E001
9243	T009	2026-01-16 23:16:19.753065	43	E004
9244	T024	2026-02-08 15:37:29.784213	39	E001
9245	T002	2026-01-13 08:07:30.111939	6	E003
9246	T017	2026-01-25 19:57:18.792298	29	E003
9247	T021	2026-02-06 02:39:41.884888	8	E003
9248	T030	2026-02-13 15:03:32.542199	27	E001
9249	T006	2026-01-16 13:42:43.028061	21	E005
9250	T013	2026-01-16 08:06:40.080636	47	E001
9251	T019	2026-01-23 20:49:33.962224	20	E001
9252	T009	2026-01-12 12:45:58.53723	10	E003
9253	T008	2026-01-10 23:03:31.718036	8	E002
9254	T020	2026-01-29 04:22:04.973038	28	E001
9255	T009	2026-01-11 23:18:14.298494	15	E005
9256	T003	2026-01-05 16:47:55.431604	1	E004
9257	T006	2026-01-11 06:58:48.422218	24	E002
9258	T001	2026-01-11 13:09:33.186879	37	E002
9259	T023	2026-02-05 14:24:33.521495	33	E004
9260	T015	2026-01-26 10:49:31.643146	35	E001
9261	T001	2026-01-10 21:03:55.406438	47	E003
9262	T019	2026-01-29 13:30:00.921536	34	E003
9263	T022	2026-02-06 10:37:32.297091	2	E004
9264	T021	2026-02-09 16:51:36.621124	31	E003
9265	T024	2026-02-05 16:44:27.950251	41	E001
9266	T001	2026-01-02 11:04:00.753079	4	E003
9267	T008	2026-01-14 16:29:02.042462	24	E002
9268	T005	2026-01-11 15:01:54.974907	8	E001
9269	T005	2026-01-09 01:38:47.698733	29	E002
9270	T029	2026-02-15 09:12:40.506993	51	E003
9271	T030	2026-02-17 17:15:01.197261	15	E001
9272	T008	2026-01-17 23:08:36.942753	33	E002
9273	T009	2026-01-11 07:27:25.224004	14	E001
9274	T011	2026-01-13 23:47:10.994465	28	E001
9275	T002	2026-01-09 06:08:07.00573	21	E002
9276	T025	2026-02-12 16:54:42.000829	42	E001
9277	T017	2026-01-22 04:01:23.001602	36	E001
9278	T027	2026-02-12 01:33:22.295982	47	E004
9279	T018	2026-01-20 15:06:00.273329	5	E005
9280	T029	2026-02-15 12:19:46.779669	37	E004
9281	T014	2026-01-23 21:14:23.179972	8	E005
9282	T016	2026-01-23 03:52:13.742018	31	E001
9283	T030	2026-02-17 04:54:22.724592	50	E004
9284	T015	2026-01-24 05:51:06.837416	13	E001
9285	T008	2026-01-09 20:04:44.309502	11	E001
9286	T019	2026-01-25 05:20:55.355432	20	E001
9287	T003	2026-01-06 21:04:20.44664	36	E005
9288	T019	2026-01-26 04:46:10.609226	11	E001
9289	T004	2026-01-11 04:40:35.877504	7	E002
9290	T018	2026-01-24 20:54:12.858981	17	E001
9291	T024	2026-02-12 03:39:31.974035	13	E002
9292	T024	2026-02-05 09:51:51.941818	21	E001
9293	T016	2026-01-22 16:59:39.851008	36	E002
9294	T013	2026-01-18 22:33:17.401189	23	E004
9295	T004	2026-01-12 01:06:47.905606	14	E002
9296	T025	2026-02-11 10:12:06.4012	31	E001
9297	T029	2026-02-14 17:23:27.740151	31	E002
9298	T012	2026-01-23 11:18:02.549258	8	E004
9299	T008	2026-01-09 10:06:25.054916	51	E004
9300	T021	2026-02-11 19:41:59.979214	48	E003
9301	T022	2026-02-08 14:14:35.73848	16	E004
9302	T024	2026-02-12 03:09:05.000776	12	E003
9303	T006	2026-01-16 10:46:39.053979	31	E004
9304	T009	2026-01-19 15:33:23.519183	19	E002
9305	T015	2026-01-25 16:04:25.273989	38	E005
9306	T007	2026-01-17 14:48:39.36892	44	E003
9307	T017	2026-01-23 07:54:45.712561	38	E002
9308	T023	2026-02-13 04:11:11.050347	49	E005
9309	T028	2026-02-17 12:59:09.066684	8	E001
9310	T007	2026-01-10 15:58:38.612495	11	E002
9311	T004	2026-01-13 09:47:20.058166	41	E004
9312	T019	2026-01-28 22:32:29.769837	29	E005
9313	T005	2026-01-12 19:15:52.71278	33	E005
9314	T005	2026-01-15 11:11:33.180187	37	E005
9315	T002	2026-01-07 15:56:43.643203	32	E003
9316	T015	2026-01-19 15:35:31.730555	19	E002
9317	T019	2026-01-21 07:35:45.328999	35	E001
9318	T004	2026-01-09 05:38:35.813792	2	E004
9319	T004	2026-01-11 19:21:19.397875	5	E003
9320	T020	2026-01-25 10:30:39.967597	45	E005
9321	T007	2026-01-12 18:22:49.908183	1	E001
9322	T002	2026-01-11 00:22:19.381219	48	E003
9323	T002	2026-01-04 04:59:16.628919	11	E003
9324	T014	2026-01-19 20:05:36.724127	29	E005
9325	T015	2026-01-19 00:17:48.320964	12	E005
9326	T026	2026-02-11 08:50:21.879425	1	E004
9327	T014	2026-01-24 10:22:16.019602	31	E004
9328	T020	2026-01-25 14:35:32.270688	27	E003
9329	T025	2026-02-12 04:51:46.314087	25	E003
9330	T016	2026-01-17 21:29:11.429808	17	E003
9331	T010	2026-01-14 22:09:14.63057	18	E003
9332	T021	2026-02-05 07:03:44.997509	10	E002
9333	T005	2026-01-12 02:59:58.512092	7	E005
9334	T013	2026-01-21 10:17:51.283232	2	E003
9335	T025	2026-02-06 18:40:10.899834	26	E002
9336	T021	2026-02-06 18:55:45.908328	45	E001
9337	T004	2026-01-11 11:35:33.415629	21	E001
9338	T013	2026-01-17 19:21:44.815001	3	E005
9339	T003	2026-01-10 16:29:49.641527	43	E005
9340	T029	2026-02-11 20:03:37.546718	29	E004
9341	T013	2026-01-15 02:03:18.402726	32	E001
9342	T002	2026-01-11 03:20:18.824399	1	E004
9343	T011	2026-01-17 03:29:38.816258	50	E004
9344	T022	2026-02-05 18:37:09.547127	47	E001
9345	T007	2026-01-12 07:03:40.077245	23	E005
9346	T009	2026-01-11 22:41:36.614611	8	E005
9347	T025	2026-02-13 20:29:24.85935	27	E002
9348	T007	2026-01-13 23:58:02.73696	2	E001
9349	T023	2026-02-09 04:58:59.232768	10	E002
9350	T017	2026-01-27 02:20:46.015034	11	E004
9351	T016	2026-01-17 20:02:02.224449	1	E004
9352	T001	2026-01-09 10:34:55.404278	44	E003
9353	T003	2026-01-08 10:11:31.954599	7	E002
9354	T027	2026-02-16 14:50:52.12159	39	E002
9355	T002	2026-01-05 21:22:23.399845	36	E004
9356	T010	2026-01-15 10:24:21.332005	10	E003
9357	T025	2026-02-12 07:27:27.485844	13	E004
9358	T018	2026-01-24 18:42:04.523221	26	E005
9359	T007	2026-01-18 02:46:55.186011	47	E005
9360	T028	2026-02-16 22:42:18.100319	27	E004
9361	T012	2026-01-13 19:10:59.026503	26	E005
9362	T019	2026-01-21 04:11:21.136989	16	E003
9363	T018	2026-01-29 05:50:40.043649	10	E002
9364	T028	2026-02-15 05:04:18.250849	33	E003
9365	T021	2026-02-04 10:21:48.685989	36	E002
9366	T010	2026-01-20 02:31:34.867798	5	E004
9367	T022	2026-02-13 02:48:29.722564	38	E005
9368	T026	2026-02-15 07:31:01.869188	16	E005
9369	T005	2026-01-13 01:44:37.893043	17	E003
9370	T004	2026-01-13 04:27:52.43012	51	E004
9371	T016	2026-01-19 01:33:14.148947	49	E004
9372	T025	2026-02-07 04:23:00.895565	13	E005
9373	T015	2026-01-22 02:13:50.857536	6	E005
9374	T026	2026-02-17 00:54:54.51025	12	E003
9375	T024	2026-02-06 02:07:34.635829	37	E001
9376	T011	2026-01-15 21:53:13.795826	9	E003
9377	T023	2026-02-07 12:59:41.47072	23	E003
9378	T005	2026-01-10 18:26:34.096014	41	E004
9379	T019	2026-01-22 09:40:31.877186	20	E004
9380	T008	2026-01-14 22:14:14.376473	50	E001
9381	T029	2026-02-16 13:41:32.939268	24	E001
9382	T021	2026-02-12 06:57:52.463272	23	E001
9383	T007	2026-01-09 16:14:35.595003	44	E003
9384	T007	2026-01-13 23:35:58.682501	29	E001
9385	T022	2026-02-05 00:55:13.343827	22	E002
9386	T021	2026-02-05 21:39:09.962811	27	E004
9387	T007	2026-01-13 00:06:14.118158	1	E004
9388	T025	2026-02-08 04:40:49.074321	11	E003
9389	T017	2026-01-21 04:22:59.235773	3	E005
9390	T018	2026-01-22 01:53:41.40491	30	E004
9391	T007	2026-01-11 00:20:08.57493	14	E005
9392	T005	2026-01-10 17:24:24.740446	15	E002
9393	T025	2026-02-11 19:18:43.275376	46	E001
9394	T024	2026-02-13 23:12:13.503891	22	E004
9395	T020	2026-01-27 15:11:11.171482	18	E005
9396	T003	2026-01-08 13:03:53.050942	17	E004
9397	T015	2026-01-24 12:25:00.831298	37	E002
9398	T030	2026-02-14 13:12:04.486622	7	E001
9399	T025	2026-02-14 07:11:56.350104	1	E004
9400	T028	2026-02-09 08:19:16.319166	36	E003
9401	T022	2026-02-04 07:05:04.367601	26	E005
9402	T012	2026-01-14 22:12:43.639786	29	E001
9403	T017	2026-01-28 09:52:39.847714	3	E001
9404	T010	2026-01-16 03:49:43.693047	48	E004
9405	T019	2026-01-20 09:39:23.340634	15	E002
9406	T028	2026-02-11 12:36:41.218202	5	E004
9407	T005	2026-01-13 02:48:17.421125	50	E003
9408	T004	2026-01-12 15:32:48.053849	45	E002
9409	T027	2026-02-11 16:25:31.248249	44	E001
9410	T016	2026-01-25 18:51:26.795273	19	E005
9411	T017	2026-01-25 03:29:53.497826	14	E003
9412	T019	2026-01-24 19:33:12.956591	16	E004
9413	T005	2026-01-07 22:29:00.372485	29	E002
9414	T029	2026-02-11 02:07:16.794949	24	E002
9415	T001	2026-01-09 03:48:16.745295	7	E004
9416	T030	2026-02-15 18:56:54.802544	23	E005
9417	T022	2026-02-06 08:44:18.656444	18	E004
9418	T018	2026-01-25 10:11:24.088008	2	E003
9419	T004	2026-01-12 03:01:12.176779	36	E005
9420	T007	2026-01-09 10:59:31.316715	7	E004
9421	T014	2026-01-20 04:15:52.035978	36	E004
9422	T012	2026-01-21 03:56:51.92296	46	E003
9423	T016	2026-01-19 04:54:00.118109	48	E001
9424	T001	2026-01-10 09:22:00.894794	17	E002
9425	T001	2026-01-05 06:59:44.732769	14	E003
9426	T018	2026-01-23 07:50:37.282677	26	E002
9427	T015	2026-01-22 22:54:58.843195	9	E003
9428	T023	2026-02-09 23:48:44.542023	13	E002
9429	T008	2026-01-14 09:25:32.468959	32	E004
9430	T029	2026-02-10 17:52:30.595914	43	E001
9431	T021	2026-02-04 23:36:37.912584	16	E003
9432	T003	2026-01-07 02:25:22.921787	22	E001
9433	T028	2026-02-17 00:31:42.930096	35	E004
9434	T028	2026-02-11 14:21:57.502758	33	E002
9435	T002	2026-01-07 22:51:33.576427	11	E003
9436	T020	2026-01-21 22:11:24.58249	49	E003
9437	T029	2026-02-11 19:42:45.487358	3	E005
9438	T008	2026-01-17 04:42:42.196801	10	E001
9439	T023	2026-02-14 13:33:54.401877	11	E003
9440	T024	2026-02-15 17:43:55.71317	31	E003
9441	T021	2026-02-08 03:02:43.740357	14	E005
9442	T024	2026-02-06 21:10:00.684521	27	E005
9443	T027	2026-02-11 08:58:49.11164	30	E005
9444	T016	2026-01-23 14:07:55.180233	45	E003
9445	T015	2026-01-18 23:44:16.622712	9	E005
9446	T018	2026-01-21 11:42:56.824943	47	E002
9447	T021	2026-02-03 09:28:23.926585	36	E003
9448	T019	2026-01-24 23:44:47.041303	36	E002
9449	T020	2026-01-25 12:09:00.103836	4	E004
9450	T011	2026-01-15 01:38:43.027499	11	E004
9451	T028	2026-02-15 03:28:41.283626	37	E005
9452	T012	2026-01-14 02:21:22.088509	15	E001
9453	T005	2026-01-13 20:54:20.2726	19	E004
9454	T002	2026-01-07 19:56:07.486033	22	E004
9455	T030	2026-02-11 23:52:11.807646	2	E001
9456	T001	2026-01-02 22:55:24.484798	13	E003
9457	T028	2026-02-10 04:49:32.940423	13	E002
9458	T023	2026-02-11 01:05:09.817223	17	E005
9459	T028	2026-02-13 11:30:31.407031	15	E005
9460	T027	2026-02-16 00:31:27.313772	39	E003
9461	T019	2026-01-29 02:38:36.201344	27	E002
9462	T004	2026-01-09 19:29:46.983055	16	E004
9463	T014	2026-01-24 18:11:35.374928	18	E005
9468	T001	2026-01-18 20:41:43.563398	62	E001
\.
;

--
-- Name: task_exec__exec_id_seq; Type: SEQUENCE SET; Schema: public; Owner: u
--

SELECT pg_catalog.setval('task_exec__exec_id_seq', 9487, true);


--
-- Name: employee__pkey; Type: CONSTRAINT; Schema: public; Owner: u; Tablespace: 
--

ALTER TABLE employee_
    ADD CONSTRAINT employee__pkey PRIMARY KEY  (emp_id);


--
-- Name: product__pkey; Type: CONSTRAINT; Schema: public; Owner: u; Tablespace: 
--

ALTER TABLE product_
    ADD CONSTRAINT product__pkey PRIMARY KEY  (product_id);


--
-- Name: task__pkey; Type: CONSTRAINT; Schema: public; Owner: u; Tablespace: 
--

ALTER TABLE task_
    ADD CONSTRAINT task__pkey PRIMARY KEY  (task_id);


--
-- Name: task_exec__pkey; Type: CONSTRAINT; Schema: public; Owner: u; Tablespace: 
--

ALTER TABLE task_exec_
    ADD CONSTRAINT task_exec__pkey PRIMARY KEY  (exec_id);


--
-- Name: idx_task__product_id; Type: INDEX; Schema: public; Owner: u; Tablespace: 
--

CREATE INDEX idx_task__product_id ON task_ USING btree (product_id) TABLESPACE pg_default;


--
-- Name: idx_task_exec__operator_id; Type: INDEX; Schema: public; Owner: u; Tablespace: 
--

CREATE INDEX idx_task_exec__operator_id ON task_exec_ USING btree (operator_id) TABLESPACE pg_default;


--
-- Name: idx_task_exec__task_id; Type: INDEX; Schema: public; Owner: u; Tablespace: 
--

CREATE INDEX idx_task_exec__task_id ON task_exec_ USING btree (task_id) TABLESPACE pg_default;


--
-- Name: trg_task_completion_au; Type: TRIGGER; Schema: public; Owner: u
--

CREATE TRIGGER trg_task_completion_au AFTER UPDATE ON public.task_ FOR EACH ROW EXECUTE PROCEDURE public.check_task_completion();


--
-- Name: trg_task_exec_check; Type: TRIGGER; Schema: public; Owner: u
--

CREATE TRIGGER trg_task_exec_check BEFORE INSERT OR UPDATE ON public.task_exec_ FOR EACH ROW EXECUTE PROCEDURE public.check_quantity_check_();


--
-- Name: trg_task_status_bu; Type: TRIGGER; Schema: public; Owner: u
--

CREATE TRIGGER trg_task_status_bu BEFORE UPDATE ON public.task_ FOR EACH ROW EXECUTE PROCEDURE public.update_task_status();


--
-- Name: update_task_quantity_trigger_; Type: TRIGGER; Schema: public; Owner: u
--

CREATE TRIGGER update_task_quantity_trigger_ AFTER INSERT OR DELETE OR UPDATE ON public.task_exec_ FOR EACH ROW EXECUTE PROCEDURE public.update_task_quantity_trigger_();


--
-- Name: task__product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: u
--

ALTER TABLE task_
    ADD CONSTRAINT task__product_id_fkey FOREIGN KEY (product_id) REFERENCES product_(product_id);


--
-- Name: task_exec__operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: u
--

ALTER TABLE task_exec_
    ADD CONSTRAINT task_exec__operator_id_fkey FOREIGN KEY (operator_id) REFERENCES employee_(emp_id);


--
-- Name: task_exec__task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: u
--

ALTER TABLE task_exec_
    ADD CONSTRAINT task_exec__task_id_fkey FOREIGN KEY (task_id) REFERENCES task_(task_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: omm
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM omm;
GRANT CREATE,USAGE ON SCHEMA public TO omm;
GRANT USAGE ON SCHEMA public TO PUBLIC;


--
-- openGauss database dump complete
--

