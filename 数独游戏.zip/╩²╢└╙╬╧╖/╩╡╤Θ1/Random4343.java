import java.util.Arrays;
import java.util.Random;

public class Random4343{
	public static void main(String args[]){
		
			int[][] array = new int[5][5];
			int outerSum = 0;
			int diagSum = 0;
			Random random = new Random();
			
			System.out.println("生成的5×5数组为：");
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 5; j++) {
					array[i][j] = random.nextInt(50)+1;
					System.out.print(array[i][j] > 9 ? array[i][j] + " " : "0" + array[i][j] + " ");
					if(i==0 || i==4 || j==0 || j==4) {
						outerSum += array[i][j];
					}
				}
				System.out.println();
			}
			System.out.println("最外圈元素之和为："+ outerSum );
			
			for (int i = 0; i < 5; i++) {
				diagSum += array[i][i];
			}
			System.out.println("对角线元素之和为："+ diagSum);
			
	}
}
