import java.util.Scanner;
import java.util.Random;

public class GuessNumber4343 {
    private static int score = 0; // 总得分
    private static Scanner scanner = new Scanner(System.in);
    private static boolean playing = true;
    
    public static void main(String[] args) {
        
        
        System.out.println("欢迎游玩猜数游戏！");
        System.out.println("当前得分: " + score);
        System.out.println("——————游戏菜单——————");
        System.out.println("1. 开始");
        System.out.println("2. 退出");
        System.out.print("请选择: ");
        
       
        
        while (playing) {
        	 int choice = scanner.nextInt();
            
            switch (choice) {
                case 1:
                    playGame();
                    break;
                case 2:
                    quitGame();
                    break;
                default:
                    System.out.println("输入错误，请重新输入");
                    System.out.println("———————————————————");
                    System.out.println("1. 开始");
                    System.out.println("2. 退出");
                    break;
            }
        }
    }
    
    private static void playGame() {
        Random random = new Random();
        int target = random.nextInt(100); // 0-99的随机数
        int times = 0;
        boolean guessed = false;
        
        System.out.println("已生成一个0-99的随机数，开始猜测吧！");
        
        while (times < 3 && !guessed) {
            System.out.print("请输入你猜的数: ");
            int guess = scanner.nextInt();
            times++;
            
            if (guess == target) {
                guessed = true;
                switch (times) {
                    case 1: score += 3; break;
                    case 2: score += 2; break;
                    case 3: score += 1; break;
                }
                System.out.println("恭喜你猜对了！");
            } else if (guess < target) {
                System.out.println("太小了！");
            } else {
                System.out.println("太大了！");
            }
        }
        
        if (!guessed) {
            System.out.println("游戏结束，正确答案是: " + target);
            score -= 2;
        }
        
        // 游戏结束后菜单
        System.out.println("当前得分: " + score);
        System.out.println("———————————————————");
        System.out.println("1. 再来一次");
        System.out.println("2. 退出");
        System.out.print("请选择: ");
    }

    private static void quitGame() {
    	System.out.println("游戏结束，最终得分: " + score);
    	playing = false;
    }
}