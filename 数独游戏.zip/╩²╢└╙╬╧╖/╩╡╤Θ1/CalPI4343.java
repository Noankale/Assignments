import java.util.Random;


public class CalPI4343 {
	
	public static void main(String args[])
	{
		
        int pointsTotal = 100000; 
        int pointsInside = 0;
        Random random = new Random();

        for (int i = 0; i < pointsTotal; i++) {
            double x = random.nextDouble(); 
            double y = random.nextDouble(); 
            
            if (x * x + y * y <= 1.0) {
            	pointsInside++;
            }
        }

        double estimatedPi = 4.0 * pointsInside / pointsTotal;
        System.out.printf("随机点数: %,d%n", pointsTotal);
        System.out.printf("落在四分之一圆内的点数: %,d%n", pointsInside);
        System.out.printf("估计的π值: %.6f%n", estimatedPi);
    }
}
