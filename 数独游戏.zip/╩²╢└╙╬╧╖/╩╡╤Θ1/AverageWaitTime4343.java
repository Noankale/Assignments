import java.util.Random;

public class AverageWaitTime4343 {
    public static void main(String[] args) {
        int trials = 1_000000;  // 模拟次数
        Random rand = new Random();
        double totalWait = 0;

        for (int i = 0; i < trials; i++) {
            // 生成0-30之间的随机到达时间和堵车时间
            double T = rand.nextDouble() * 30;
            double D = rand.nextDouble() * 30;
            
            // 计算单次等待时间并累加
            double waitTime = 40 + D - T;
            totalWait += waitTime;
        }

        // 计算并输出平均等待时间
        double average = totalWait / trials;
        System.out.printf("平均等待时间：%.2f 分钟%n", average);
    }
}
