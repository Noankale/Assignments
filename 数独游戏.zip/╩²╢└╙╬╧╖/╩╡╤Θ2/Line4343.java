import java.util.Arrays;

class InputScore{
	private DelScore nextHandler;
	public InputScore(DelScore nextHandler) {
		this.nextHandler = nextHandler;
	}
	
	public double[] handler(double[] scores) {
		System.out.println("录入分数：" + Arrays.toString(scores));
		return nextHandler.handler(scores);
	}
}

class DelScore{
	private ComputerAver nextHandler;
	public DelScore(ComputerAver nextHandler) {
		this.nextHandler = nextHandler;
	}
	
	public double[] handler(double[] scores) {
		
		if( scores == null || scores.length <= 2) return scores;
		
		Arrays.sort(scores);
		double[] delScores = Arrays.copyOfRange(scores, 1, scores.length - 1);
		
		
		
		return nextHandler.handler(delScores);
	}
	
}

class ComputerAver{
	public double[] handler(double[] scores) {
		
		 if (scores == null || scores.length == 0) {
	            return new double[]{0};
	        }
		double sum = 0;
		for(int i = 0;i< scores.length ; i++) {
			sum += scores[i];
		}
		
		double average = sum/scores.length;
		System.out.println("平均分为: " + average);
		return new double[] {average};
		
		
	}
}

public class Line4343 {
	private InputScore inputScore;
    private DelScore delScore;
    private ComputerAver computerAver;
    
    public Line4343() {
    	computerAver = new ComputerAver();
    	delScore = new DelScore(computerAver);
    	inputScore = new InputScore(delScore);
    }
    
    public double handler(double[] scores) {
    	double[] result = inputScore.handler(scores);
    	return result[0];
    }
    
	
	public static void main(String[] args) {
		Line4343 stream = new Line4343();
		
		double scores[] = {7.4, 9.0, 7.8, 9.5, 8.8, 9.2};
		
		double finalScore = stream.handler(scores);
		System.out.println("最终得分: " + finalScore);
		
		
		
	}

}
