import java.time.LocalDate;

abstract class Employee{
	private int id;
	private String name;
	private LocalDate birthDate;
	
	public Employee(int id,String name,LocalDate birthDate) {
		this.id = id;
		this.name = name;
		this.birthDate = birthDate;
	}
	
	public abstract double calculateIncome();
	
	public boolean isBirthMonth(int curMonth) {
		return birthDate.getMonthValue() == curMonth;
	};
	
	public double calculateAllIncome(int curMonth) {
		double baseIncom = calculateIncome();
		if(isBirthMonth(curMonth)) baseIncom += 100;
		return baseIncom;
	}
	
	public int getId() {
		return id;
		}
	public String getname() {
		return name;
		}
	public LocalDate getbirthDate() {
		return birthDate;
		}
	
	public String toString() {
		return "ID " + id + "\t姓名 " + name + "\t生日 " + birthDate + "\t 本月工资 " + String.format("%.2f", calculateAllIncome(LocalDate.now().getMonthValue()));
	}
	
}

class SalariedEmployee extends Employee{
	private double salary;
	
	public SalariedEmployee(int id, String name,LocalDate birthDate, double salary) {
		super(id, name, birthDate);
		this.salary = salary;
	}
	
	public double calculateIncome() {
		return salary;
	}
}

class HourlyEmployee extends Employee{
	private double  hourlySalary;
	private int workHours;
	
	public HourlyEmployee(int id, String name,LocalDate birthDate, double hourlySalary,int workHours) {
		super(id, name, birthDate);
		this.hourlySalary = hourlySalary;
		this.workHours = workHours;
	}
	
	public double calculateIncome() {
		if(workHours <= 160) {
			return hourlySalary * workHours;
		}
		else {
			return hourlySalary * 160 + ( workHours - 160 )*1.5;
		}
	}
}

class CommissionEmployee extends Employee{
	private double sales;
	private double commission;
	
	public CommissionEmployee(int id, String name,LocalDate birthDate, double sales, double commission) {
		super(id, name, birthDate);
		this.sales = sales;
		this.commission = commission;
	}
	
	public double calculateIncome() {
		return sales * commission;
	}
}

class BasePlusCommissionEmployee extends CommissionEmployee{
	private double baseSalary;
	
	public BasePlusCommissionEmployee(int id, String name,LocalDate birthDate, double sales, double commission,double baseSalary) {
		super(id, name, birthDate, sales, commission);
		this.baseSalary = baseSalary;
	}
	
	public double calculateIncome() {
		return super.calculateIncome() + baseSalary;
	}
}

public class Employee4343 {
	
	public static void main(String[] args) {
		int curMonth = LocalDate.now().getMonthValue();
		
		Employee[] employees = new Employee[4];
		
		int staffNum = 0;
		
		employees[0] = new SalariedEmployee(++staffNum, "A", LocalDate.of(1990, 5, 15), 5000.0);
        employees[1] = new HourlyEmployee(++staffNum, "B", LocalDate.of(1995, curMonth, 20), 20.0, 180);
        employees[2] = new CommissionEmployee(++staffNum, "C", LocalDate.of(1988, 10, 5), 50000.0, 0.1);
        employees[3] = new BasePlusCommissionEmployee(++staffNum, "D", LocalDate.of(1992, 8, 12), 
                                                     30000.0, 0.05, 2000.0);
		
        System.out.println("员工工资信息");
        for (Employee emp : employees) {
            System.out.println(emp);
        }
	}
	
}