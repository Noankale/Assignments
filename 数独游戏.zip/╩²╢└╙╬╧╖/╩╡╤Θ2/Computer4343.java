interface PCI{
	void start();
	void run();
	void stop();
}

class GraphicsC implements PCI{
	public void start() {
		System.out.print("显卡启动-");
	}
	public void run() {
		System.out.print("-显卡运行 ");
	}
	public void stop() {
		System.out.print("显卡停止 ");
	}
	
}

class SoundC implements PCI{
	public void start() {
		System.out.print("声卡启动-");
	}
	public void run() {
		System.out.print("-声卡运行 ");
	}
	public void stop() {
		System.out.print("声卡停止 ");
	}
	
}

class NIC implements PCI{
	public void start() {
		System.out.print("网卡启动-");
	}
	public void run() {
		System.out.print("-网卡运行");
	}
	public void stop() {
		System.out.print("网卡停止 ");
	}
	
}

class Mainboard{
	private PCI[] slots;
	
	public Mainboard() {
		slots = new PCI[5];
	}
	
	public void insert(int index, PCI device) {
		if(index >= 0 && index < slots.length) {
			slots[index] = device;
		}
		else {
			System.out.println("插槽编号无效");
		}
	}
	
	public void start() {
		System.out.print("【开机】");
        for (PCI device : slots) {
            if (device != null) {
                device.start();
                device.run();
            }
        }
	}
	
	 public void stop() {
	        System.out.print("【关机】");
	        for (PCI device : slots) {
	            if (device != null) {
	                device.stop();
	            }
	        }
	    }
	
}

public class Computer4343 {
    private Mainboard mainboard;

    public Computer4343() {
    	mainboard = new Mainboard();
    }

    public void start() {
    	mainboard.start();
    	System.out.println();
    }

    public void stop() {
    	mainboard.stop();
    	System.out.println();
    }
    
    public static void main(String[] args) {
        Computer4343 computer = new Computer4343();

        computer.mainboard.insert(0, new GraphicsC());
        computer.mainboard.insert(1, new SoundC());
        computer.mainboard.insert(2, new NIC());

        computer.start();

        computer.stop();
    }
}


