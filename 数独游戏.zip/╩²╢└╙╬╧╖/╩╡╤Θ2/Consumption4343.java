import java.security.KeyStore.PrivateKeyEntry;
import java.util.ArrayList;
import java.util.List;

class Card4343{
    private int id;
    private String name;
    private String password;
    private double balance;
    
    public Card4343(int id, String name, String password, double balance) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.balance = balance;
        System.out.println("创建银行卡: " + id + " 持有人: " + name + " 余额: " + balance);
    }
    
    public int getID() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    public String getPassword() {
        return password;
    }
    
    public double getBalance() {
        return balance;
    }
    
    public boolean verify(String p) {
        return p.equals(password);
    }
    
    public void Chargebacks(double amount) {
        if(balance >= amount) {
            balance -= amount;
            System.out.println("银行卡 " + id + " 扣款 " + amount + " 成功，当前余额: " + balance);
        } else {
            System.out.println("银行卡 " + id + " 扣款失败，余额不足，当前余额: " + balance + "，需要扣款: " + amount);
        }
    }
    
}


public class Consumption4343 {
    private List<Card4343> cards;
    private String password;
    private int cardNum;
    
    public Consumption4343(String password) {
        this.password = password;
        cards = new ArrayList<Card4343>(3);
        cardNum = 0;
        System.out.println("创建消费宝账户，初始密码: " + password);
    }
    
    public boolean linkCard4343(Card4343 card, String cardPassword) {
        if( cards.size() >= 3) {
            System.out.println("最多可关联三张银行卡。");
            return false;
        }
        
        if(card.verify(cardPassword)) {
            cards.add(card);
            cardNum++;
            System.out.println("银行卡 " + card.getID() + " 关联成功");
            System.out.println("当前已关联 " + cards.size() + " 张银行卡");
            return true;
        }
        else {
            System.out.println("银行卡 " + card.getID() + " 关联失败:密码错误");
            return false;
        }
    }
    
    public boolean unlinkCard4343(int id, String cardPassword) {
        boolean find = false;
         for (Card4343 card : cards) {
             if (card.getID() == id) {
                 if(card.verify(cardPassword)) {
                     cards.remove(card);
                     cardNum--;
                     System.out.println("银行卡 " + id + " 取消关联成功");
                     System.out.println("当前已关联 " + cards.size() + " 张银行卡");
                     return true;
                 }
                 else {
                     System.out.println("银行卡 " + id + " 取消关联失败：银行卡密码错误。");
                     return false;
                 }
            }
        }
         System.out.println("银行卡 " + id + " 取消关联失败：未找到该银行卡。");
         return false;
    }
    
    public boolean pay(String p, double amount){
        System.out.println("支付金额: " + amount);
        
        if(cards.isEmpty()) {
            System.out.println("支付失败：未关联任何银行卡。");
            return false;
        }
        
        if(!password.equals(p)) {
            System.out.println("支付失败：消费宝密码错误。");
            return false;
        }
        
        double allBalance = 0;
        for(Card4343 card:cards) {
            allBalance += card.getBalance();
        }
        
        System.out.println("消费宝可用余额: " + allBalance);
        
        if(allBalance < amount) {
            System.out.println("支付失败：消费宝余额不足。");
            return false;
        }
        else {
            for (Card4343 card:cards) {
                if(amount <= 0) {
                    break;
                }
                
                
                if(card.getBalance() >= amount ) {
                    card.Chargebacks(amount);
                    System.out.println("从银行卡 " + card.getID() + " 扣款 " + amount);
                    amount = 0;
                    break;
                }
                else {
                    double cardBalance = card.getBalance();
                    card.Chargebacks(cardBalance);
                    amount -= cardBalance;
                    System.out.println("从银行卡 " + card.getID() + " 扣款 " + cardBalance);
                }
            }
            
            if(amount <= 0) {
                System.out.println("支付成功。");
                return true;
            } else {
                System.out.println("支付失败。");
                return false;
            }
        }
    }
    
    public static void main(String[] args) {
        Consumption4343 comsumption = new Consumption4343("123456");
        
        Card4343 Card43431 = new Card4343(
                1234,
                "张三",
                "1111",
                800.50
        );
        
        Card4343 Card43432 = new Card4343(
                1235,
                "张三",
                "2222",
                2000.46
        );
        
        comsumption.linkCard4343(Card43431, "1111");
        comsumption.linkCard4343(Card43432, "1");
        comsumption.linkCard4343(Card43432, "2222");
        
        comsumption.pay("123456", 800.00);
        comsumption.pay("123456", 100.00);
        comsumption.pay("123456", 2000.00);
        
        comsumption.unlinkCard4343(1234, "1111");
        
    }
}