package game;

import java.io.*;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

class Sodoku4343{
	private double level;
	private int size;
	private int board[][];
	private int boardFin[][];
	public int boardUser[][];
	private String filePath;
	
	public String getFilPath() {
		return filePath;
	}
	
	public int getSize() {
	    return this.size;
	}
	
	public Sodoku4343(int size, String filePath, double level) {
		this.level = level;
		this.size = size;
		this.filePath = filePath;
		this.board = new int[size][size];
		this.boardFin = new int[size][size];
		this.boardUser = new int[size][size];
	}
	
	
	public void generateSodoku() {
		backTracking(0, 0);
		for (int i = 0; i < size; i++) {
            System.arraycopy(boardFin[i], 0, board[i], 0, size);
        }
		int emptyGrid = (int)(size*size*level);
		Random random = new Random();
		while(emptyGrid != 0) {
			int row = random.nextInt(size);
			int col = random.nextInt(size);
			if(board[row][col]!=0) {
				board[row][col] = 0;
				emptyGrid--;
			}
		}
		
		for (int i = 0; i < size; i++) {
            System.arraycopy(board[i], 0, boardUser[i], 0, size);
        }
	}
	
	public boolean backTracking(int row, int col) {
	    if (row == size) {
	        return true; // 数独生成完毕
	    }
	    if (col == size) {
	        return backTracking(row + 1, 0); // 当前行填完，跳到下一行第0列
	    }

	    List<Integer> nums = new ArrayList<>();
	    for (int i = 1; i <= size; i++) {
	        nums.add(i);
	    }
	    Collections.shuffle(nums);

	    for (int num : nums) {
	        if (isValid(row, col, num,boardFin)) {
	            boardFin[row][col] = num;
	            if (backTracking(row, col + 1)) { 
	                return true;
	            }
	            boardFin[row][col] = 0;
	        }
	    }
	    return false;
	}
	
	// 检查当前数字是否可以填入当前格子
	public boolean isValid(int row, int col, int num, int[][] board) {
	    // 检查行和列
	    for(int i = 0; i < size; i++) {
	        if(board[row][i] == num || board[i][col] == num) {
	            return false;
	        }
	    }
	    
	    // 检查大格子
	    if(size == 4) {
	        int boxCol = (col/2)*2;
	        int boxRow = (row/2)*2;
	        for(int i = boxRow; i < boxRow+2; i++) {
	            for(int j = boxCol; j < boxCol+2; j++) {
	                if(board[i][j] == num) {
	                    return false;
	                }
	            }
	        }
	    }
	    else if(size == 6) {
	        int boxCol = (col/3)*3;
	        int boxRow = (row/2)*2;
	        for(int i = boxRow; i < boxRow+2; i++) {
	            for(int j = boxCol; j < boxCol+3; j++) {
	                if(board[i][j] == num) return false;
	            }
	        }
	    }
	    else if(size == 9) {
	        int boxCol = (col/3)*3;
	        int boxRow = (row/3)*3;
	        for(int i = boxRow; i < boxRow+3; i++) {
	            for(int j = boxCol; j < boxCol+3; j++) {
	                if(board[i][j] == num) return false;
	            }
	        }
	    }
	    
	    // 检查对角线
	    if(row == col) {
	        for(int i = 0; i < size; i++) {
	            if(board[i][i] == num) return false;
	        }
	    }
	    if(row + col == size - 1) {
	        for(int i = 0; i < size; i++) {
	            if(board[i][size-1-i] == num) return false;
	        }
	    }
	    
	    return true;
	}
	
	public boolean checkSodoku(int[][] boardUser) {
		boolean s = true;
		for(int i = 0 ; i<size ; i++) {
			for(int j = 0; j<size; j++) {
				if(board[i][j] == 0 && boardUser[i][j] != 0) {
					if(!isValid(i, j, boardUser[i][j],board)){
						s = false;
						boardUser[i][j] = 0;
					}
				}
				else if(boardUser[i][j]==0) {
					System.out.println("还有未填写的格子:（"+i+","+j+")");
					s = false;
				}
				
			}
		}
		return s;
	}
		
	public void saveSodoku() {
		File file = new File(filePath);
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))){
			 oos.writeObject(size);
			 oos.writeObject(board);
			 oos.writeObject(boardFin);
			 
			 System.out.println("数独已保存到"+filePath);
			 
		}
		catch (IOException e) {
			System.out.println("保存数独时出错。");
			 e.printStackTrace();
		}
			
	}
	
	public void loadSodoku() {
	    File file = new File(filePath);
	    try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
	        size = (int)ois.readObject();
	        board = (int[][]) ois.readObject();
	        boardFin = (int[][]) ois.readObject();
	        
	        
	        boardUser = new int[size][size];
	        for (int i = 0; i < size; i++) {
	            System.arraycopy(board[i], 0, boardUser[i], 0, size);
	        }
	        
	        System.out.println("数独已成功从 " + filePath + " 加载");
	        
	    } catch (IOException | ClassNotFoundException e) {
	        System.err.println("加载数独时出错: " + e.getMessage());
	        e.printStackTrace();
	    }         
	}
	
	public int[][] getSodoku(){
		return board;
	}
	public int[][] getAnswer() {
		return boardFin;
	}
	
	public void userInput() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("请输入要填写的行、列（从1开始）和数字（用空格分隔），输入 -1 退出：");
            int row = scanner.nextInt();
            if (row == -1) {
                break;
            }
            int col = scanner.nextInt();
            int num = scanner.nextInt();
            if (row > 0 && row <= size && col > 0 && col <= size && num >= 1 && num <= size) {
            	if(board[row-1][col-1] == 0) {
            		boardUser[row-1][col-1] = num;
                    printSodoku(boardUser);
            	}
            	else {
            		  System.out.println("输入无效，请重新输入。");
            	}
            }
            else {
                System.out.println("输入无效，请重新输入。");
            }
        }
    }
	
	public void printSodoku(int[][] board) {
		for(int i=0 ; i<size ; i++) {
			for(int j=0 ; j<size; j++) {
				if(board[i][j] == 0) {
					System.out.print("· ");
				}
				else {
					System.out.print(board[i][j]+" ");
				}
				
			}
			System.out.println();
		}
	}	
}

public class Game4343 {
	
	private Sodoku4343 curSodoku;
	private int sodokuNum = 0;
	static Scanner scanner = new Scanner(System.in);
	public Game4343() {
		this.sodokuNum = updateIndex();
	}
	
	private int updateIndex() {
		File dir = new File(".");
        File[] files = dir.listFiles((d, name) -> name.matches("sodoku\\d+\\.dat"));
        int maxNum = 0;
        
        if (files != null) {
            for (File file : files) {
                try {
                    String numStr = file.getName().replace("sodoku", "").replace(".dat", "");
                    int num = Integer.parseInt(numStr);
                    if (num > maxNum) maxNum = num;
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        }
        return maxNum;
    }
	
	public void newGame() {
		sodokuNum = updateIndex();
		System.out.println("请选择数独类型：");
		System.out.println("4：四宫格\t6：六宫格\t9：九宫格");
		int size = 0;
		while(true) {
			size = scanner.nextInt();
			if(size != 4 && size !=6 && size !=9 ) {
				System.out.print("输入错误，请重新输入:");
			}
			else break;
		}
		
		System.out.println("请选择难度：");
		System.out.println("1：简单\t2：中等\t3：困难");
		int level = 0;
		double level1 = 0;
		while(true) {
			level = scanner.nextInt();
			switch(level) {
			case 1:
				level1 = 0.3;
				break;
			case 2:
				level1 = 0.5;
				break;
			case 3:
				level1 = 0.7;
				break;
			default:
				System.out.print("输入错误，请重新输入:");
			}
			if(level1 != 0) break;
		}
		
		sodokuNum ++;
		curSodoku = new Sodoku4343(size, "sodoku"+sodokuNum+".dat", level1);
		curSodoku.generateSodoku();
		curSodoku.saveSodoku();
		System.out.println("当前数独已保存为：sodoku"+sodokuNum+".dat");
		startGame();
	}
	
	public void continueGame() {
        File dir = new File(".");
        File[] files = dir.listFiles((d, name) -> name.startsWith("sodoku") && name.endsWith(".dat"));
        if (files == null || files.length == 0) {
            System.out.println("没有保存的数独游戏。");
            return;
        }
        sodokuNum = updateIndex();
        System.out.println("可用的数独游戏：");
        System.out.println("-1. 返回上一级");
        for (int i = 0; i < files.length; i++) {
            System.out.println((i + 1) + ". " + files[i].getName());
        }
        System.out.println("请选择要继续的游戏编号：");
        int choice = scanner.nextInt();
        if(choice == -1) {
        	return;
        }
        else if (choice >= 1 && choice <= files.length) {
            String filePath = files[choice - 1].getPath();
            curSodoku = new Sodoku4343(0, filePath, 0);
            curSodoku.loadSodoku();
            startGame();
        }
        else {
            System.out.println("选择无效。");
        }
    }
	
	public void startGame() {
        System.out.println("当前数独：");
        curSodoku.printSodoku(curSodoku.getSodoku());
        while (true) {
            int subChoice = 0;
            System.out.println("请选择操作：");
            System.out.println("1. 输入答案");
            System.out.println("2. 检查答案");
            System.out.println("3. 查看参考答案");
            System.out.println("4. 退出当前游戏");
            subChoice = scanner.nextInt();
            switch (subChoice) {
                case 1:
                    curSodoku.userInput();
                    break;
                case 2:
                    if (curSodoku.checkSodoku(curSodoku.boardUser)) {
                        System.out.println("本局已完成！");
                        File file = new File(curSodoku.getFilPath());
                        if (file.delete()) {
                            System.out.println("游戏文件已删除：" + curSodoku.getFilPath());
                        }
                        return;
                    } else {
                        System.out.println("检查已完成。");
                        curSodoku.printSodoku(curSodoku.boardUser);
                    }
                    break;
                case 3:
                    System.out.println("答案仅供参考，本题可能存在多解：");
                    curSodoku.printSodoku(curSodoku.getAnswer());
                    break;
                case 4:
                    return;
                default:
                    System.out.print("输入错误，请重新输入:");
                    break;
            }
        }
	}
	
	public static void main( String[] args) {
		Game4343 game = new Game4343();
		while(true) {
			System.out.println("请选择操作：");
            System.out.println("1. 开始新一局");
            System.out.println("2. 继续上一局");
            System.out.println("3. 退出");
            System.out.print("请输入选项: ");
            int choice = scanner.nextInt();
            
            switch(choice){
            	case 1:
            		game.newGame();
            		break;
            	case 2:
            		game.continueGame();
            		break;
            	case 3:
            		return;
            	default:
            		System.out.println("选择无效，请重新选择。");
            }	
		}		
	}
}
