import java.io.*;
import java.util.ArrayList;
import java.util.List;

class Student4343 implements Serializable {
    private String name;
    private int age;
    private String ID;

    public Student4343(String name, int age, String id) {
        this.name = name;
        this.age = age;
        this.ID = id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getID() {
        return ID;
    }
}

public class StudentFile4343 {
    private List<Student4343> students = new ArrayList<>();
    private File file;

    public boolean readFile(String filePath) {
        file = new File(filePath);
        
        if (!file.exists()) {
            System.out.println("打开失败:目标文件不存在。");
            return false;
        }

        try (ObjectInputStream filer = new ObjectInputStream(new FileInputStream(file))) {

            students = (List<Student4343>) filer.readObject();
            System.out.println("成功读取 " + students.size() + " 个学生记录");
            
            for (Student4343 student : students) {
                System.out.println("姓名：" + student.getName() + 
                                  "，年龄：" + student.getAge() + 
                                  "，ID：" + student.getID());
            }
            return true;
        } catch (FileNotFoundException e) {
            System.out.println("错误：文件未找到:" + e.getMessage());
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("错误:" + e.getMessage());
        }
        return false;
    }


    public boolean writeFile(String filePath) {
        file = new File(filePath);
        
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {

            oos.writeObject(students);
            System.out.println("成功写入 " + students.size() + " 个学生记录到 " + filePath);
            return true;
        } catch (IOException e) {
            System.out.println("创建文件错误：" + e.getMessage());
            return false;
        }
    }

    public static void main(String[] args) {
        String filePath = "students.dat";
        StudentFile4343 studentFile = new StudentFile4343();

        studentFile.students.add(new Student4343("A", 20, "2025001"));
        studentFile.students.add(new Student4343("B", 21, "2025002"));
        studentFile.students.add(new Student4343("C", 22, "2025003"));
        studentFile.students.add(new Student4343("D", 22, "2025004"));
        studentFile.students.add(new Student4343("E", 22, "2025005"));
        
        System.out.println("正在读取文件……");
        studentFile.readFile(filePath);
        File file1 = new File(filePath);
        
        System.out.println("正在创建文件……");

        if (studentFile.writeFile(filePath)) {
            System.out.println("创建文件成功！\n");
            
            System.out.println("正在读取文件……");
            studentFile.readFile(filePath);
        }
        
        System.out.println("文件绝对路径: " + file1.getAbsolutePath()); 
    }
}